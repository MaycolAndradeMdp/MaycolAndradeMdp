#include <windows.h>
#include <iostream>
#include <fstream> // Libreria que sirve para leer archivos
#include <string>
#include <vector>

using namespace std;

// ===== FUNCION PARA AGREGAR COLOR AL FONDO Y AL TEXTO ======
void setConsoleColors(int backgroundColor, int textColor)
{
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, (backgroundColor << 4) | textColor);
    system("cls"); // Limpia la consola para aplicar los cambios
}

// =========== CLASE TURNO ============

class Turno
{
    public:
        // === ATRIBUTOS ===
        int idTurno;
        int idDoctor;
        int idPaciente;
        string fecha;

        // === METODOS ===
        void info() const;
        void guardarArchivo();

    // ===== DECLARACION CONSTRUCTOR ========
        Turno() {}
        Turno(int idTurno, int idDoctor, int idPaciente, string fecha) : idTurno(idTurno), idDoctor(idDoctor), idPaciente(idPaciente), fecha(fecha) {}
};

// ========= DECLARACION METODO INFO ============

void Turno::info() const
{
    cout << "ID Turno: " << idTurno << endl;
    cout << "ID Doctor: " << idDoctor << endl;
    cout << "ID Paciente: " << idPaciente << endl;
    cout << "Fecha: " << fecha << endl;

}

// ========== MANEJO DE ARCHIVOS ============


 void Turno :: guardarArchivo()
    {
        ofstream archivo("turnos.txt", ios::app); // Abre el archivo para agregar datos sin sobreescribir
        if (archivo)
        {
            archivo << idTurno << "|" << idDoctor << "|" << idPaciente << "|" << fecha << endl;
            archivo.close();
        cout << "Datos guardados correctamente en turnos.txt" << endl;
        }
        else
        {
            cout << "Error al abrir el archivo" << endl;
        }
    }

// ======== CREACION DE VECTOR PARA CARGAR LOS TURNOS ======
vector<Turno> cargarTurnos()
{
    vector<Turno> turnos;

    ifstream archivo("turnos.txt");

    if (archivo) // Si el archivo esta abierto...
    {
        int idTurno, idDoctor, idPaciente;
        string fecha;

        while (archivo >> idTurno) // Lee el ID del turno (un entero), si se logra, sigue con el ciclo

        {
            archivo.ignore();
            archivo >> idDoctor;
            archivo.ignore();
            archivo >> idPaciente;
            archivo.ignore();
            getline(archivo, fecha, '|');

            turnos.push_back(Turno(idTurno, idDoctor, idPaciente, fecha)); // Push_back permite crear un objeto Doctor con los datos leidos y se a�ade al final del vector
        }

        archivo.close();
    }

    return turnos;
}

// ========== FUNCION MODIFICAR TURNOS =========

void modificarTurno(int id)
{
    bool turnoEncontrado = false;
    vector<Turno> turnos = cargarTurnos();

    // Recorrer el vector para buscar el turno el cual sera modificado.
    for (Turno& t : turnos)
    {
        if (t.idTurno == id)
        {
            turnoEncontrado = true;
            cout << "Ingrese nueva fecha: ";
            cin >> t.fecha;

            ofstream archivo("turnos.txt");
            for (const Turno& t : turnos)
            {
                archivo << t.idTurno << "|" << t.idDoctor << "|" << t.idPaciente << "|" << t.fecha << endl;
            }

            cout << "Turno modificado exitosamente" << endl;
            break;
        }

        if (!turnoEncontrado)
        {
            cout << "Error: No se encontr� un turno con el ID: " << id << endl;
        }

    }



}

// ========== FUNCION ELIMINAR TURNOS ==========

void eliminarTurno(int id)
{
    bool turnoEncontrado = false;
    vector<Turno> turnos = cargarTurnos();

    vector<Turno> turnosActualizados;

    for (const Turno& t : turnos)
    {
        if (t.idTurno != id)
        {
            turnosActualizados.push_back(t);
        }
        else
        {
            turnoEncontrado = true;
        }
    }

    if (turnoEncontrado)
    {
       ofstream archivo("turnos.txt");
        for (const Turno& t : turnosActualizados)
        {
           archivo << t.idTurno << "|" << t.idDoctor << "|" << t.idPaciente << "|" << t.fecha << endl;
        }

        cout << "Turno eliminado exitosamente." << endl;
    }
    else
    {
        cout << "Error: No se encontr� un turno con el ID: " << id << endl;
    }

}

// ========= FUNCION MOSTRAR TURNOS ============

void mostrarTurnos()
{
    vector<Turno> turnos = cargarTurnos();

    for (const Turno& t : turnos)
    {
        t.info();
    }
}

// =========== CLASE DOCTOR ============

class Doctor
{
    public:
        // === ATRIBUTOS ===
        int idDoctor;
        string nombre;
        string apellido;
        string especialidad;
        string DNI;
        int edad;
        string telefono;
        string email;

        // === METODOS ===
        void info() const;
        void guardarArchivo();

    // ===== DECLARACION CONSTRUCTOR ========
        Doctor() {}
        Doctor(int idDoctor, string nombre, string apellido, string especialidad, string DNI, int edad, string telefono, string email) : idDoctor(idDoctor), nombre(nombre), apellido(apellido), especialidad(especialidad), DNI(DNI), edad(edad), telefono(telefono), email(email) {}
};



// ========= DECLARACION METODO INFO ============

void Doctor::info() const
{
    cout << "Id: " << idDoctor << endl;
    cout << "Nombre: " << nombre << endl;
    cout << "Apellido: " << apellido << endl;
    cout << "Especialidad: " << especialidad << endl;
    cout << "Dni: " << DNI << endl;
    cout << "Edad: " << edad << endl;
    cout << "Telefono: " << telefono << endl;
    cout << "Email: " << email << endl;
}


// ========== MANEJO DE ARCHIVOS ============


void Doctor::guardarArchivo()
{
    ofstream archivo("doctores.txt", ios::app); // Abre el archivo para agregar datos sin sobreescribir
    if (archivo) {
        archivo << idDoctor << "|" << nombre << "|" << apellido << "|"
                << especialidad << "|" << DNI << "|" << edad << "|"
                << telefono << "|" << email << endl;
        archivo.close();
        cout << "Datos guardados correctamente en doctores.txt" << endl;
    }
    else
    {
        cout << "Error al abrir el archivo" << endl;
    }
}

// ======== FUNCION CARGAR DOCTORES (USO DE VECTOR) ======
vector<Doctor> cargarDoctores()
{
    vector<Doctor> doctores;

    ifstream archivo("doctores.txt");

    if (archivo)
    {
        int idDoctor, edad;
        string nombre, apellido, especialidad, telefono, email, DNI;

        while (archivo >> idDoctor)

        {
            archivo.ignore();
            getline(archivo, nombre, '|');
            getline(archivo, apellido, '|');
            getline(archivo, especialidad, '|');
            getline(archivo, DNI, '|');
            archivo >> edad;
            archivo.ignore();
            getline(archivo, telefono, '|');
            getline(archivo, email);


            doctores.push_back(Doctor(idDoctor, nombre, apellido,especialidad, DNI, edad, telefono, email)); // Push_back permite crear un objeto Doctor con los datos leidos y se a�ade al final del vector
        }

        archivo.close();
    }

    return doctores;
}

// ========= FUNCION PARA MODIFICAR DOCTORES =========

void modificarDoctor(int id)
{
    bool doctorEncontrado = false;
    vector<Doctor> doctores = cargarDoctores();

    for (Doctor& d : doctores)
    {
        if (d.idDoctor == id)
        {
            doctorEncontrado = true;
            cout << "Ingrese nuevo nombre: ";
            cin >> d.nombre;
            cout << "Ingrese nuevo apellido: ";
            cin >> d.apellido;
            cout << "Ingrese nueva especialidad: ";
            cin >> d.especialidad;
            cout << "Ingrese nuevo DNI: ";
            cin >> d.DNI;
            cout << "Ingrese nueva edad: ";
            cin >> d.edad;
            cout << "Ingrese nuevo telefono: ";
            cin >> d.telefono;
            cout << "Ingrese nuevo email: ";
            cin >> d.email;

             ofstream archivo("doctores.txt");

            for (const Doctor& d : doctores)
            {
                archivo << d.idDoctor << "|" << d.nombre << "|" << d.apellido << "|"
                        << d.especialidad << "|" << d.DNI << "|" << d.edad << "|"
                        << d.telefono << "|" << d.email << endl;
            }

            cout << "Doctor modificado exitosamente";
            break;
        }
    }

     if (!doctorEncontrado)
     {
        cout << "Error: No se encontr� un doctor con el ID: " << id << endl;
     }
}

// ========== FUNCION ELIMINAR DOCTORES ==========

void eliminarDoctor(int id)
{
     bool doctorEncontrado = false;
    vector<Doctor> doctores = cargarDoctores();

    vector<Doctor> doctoresActualizados; // Vector en el cual se cargaran los doctores excepto el eliminado

    // Recorrer la lista de doctores
    for (const Doctor& d : doctores)
    {
        if (d.idDoctor != id)
        {
            doctoresActualizados.push_back(d); // Aquellos que no coincidan con el ID se a�aden al nuevo vector
        }
        else
        {
            doctorEncontrado = true; // Si el ID coincide, marcamos que encontramos el doctor
        }
    }

    if (doctorEncontrado)
    {
        ofstream archivo("doctores.txt"); // Abrir el archivo en modo de escritura
        for (const Doctor& d : doctoresActualizados)
        {
            archivo << d.idDoctor << "|" << d.nombre << "|" << d.apellido << "|"
                    << d.especialidad << "|" << d.DNI << "|" << d.edad << "|"
                    << d.telefono << "|" << d.email << endl; // Se escribe los doctores actualizados en el archivo
        }

        cout << "Doctor eliminado exitosamente." << endl;
    }
    else
    {
        cout << "Error: No se encontr� un doctor con el ID: " << id << endl; // Mensaje de error si el doctor no existe
    }
}

// ========= FUNCION MOSTRAR DOCTORES ============

void mostrarDoctores()
{
    vector<Doctor> doctores = cargarDoctores();

    for (const Doctor& d : doctores)
    {
        d.info();
        cout << "---------------------" << endl;
    }
}

// =========== CLASE PACIENTE ============

class Paciente
{
    public:
        // === ATRIBUTOS ===
        int idPaciente;
        string nombre;
        string apellido;
        int edad;
        string DNI;
        string email;
        string telefono;

        // === METODOS ===
        void guardarArchivo();
        void info() const;

        // ===== DECLARACION CONSTRUCTOR ========
        Paciente() {}
        Paciente(int idPaciente, string nombre, string apellido, int edad, string DNI, string email, string telefono) : idPaciente(idPaciente), nombre(nombre), apellido(apellido), edad(edad), DNI(DNI), email(email), telefono(telefono) {}




};

// ======= DECLARACION METODO INFO =========
void Paciente::info() const
{
    cout << "Id: " << idPaciente << endl;
    cout << "Nombre: " << nombre << endl;
    cout << "Apellido: " << apellido << endl;
    cout << "Edad: " << edad << endl;
    cout << "Dni: " << DNI << endl;
    cout << "Email: " << email << endl;
    cout << "Telefono: " << telefono << endl;
}

// ========== MANEJO DE ARCHIVOS ============


void Paciente::guardarArchivo()
{
    ofstream archivo("pacientes.txt", ios::app); // Abre el archivo para agregar datos sin sobreescribir
    if (archivo)
    {
        archivo << idPaciente << "|" << nombre << "|" << apellido << "|" << edad << "|" << DNI << "|" << email << "|" << telefono << endl;
        archivo.close();
        cout << "Datos guardados correctamente en pacientes.txt" << endl;
    }
    else
    {
        cout << "Error al abrir el archivo" << endl;
    }
}

vector<Paciente> cargarPacientes()
{
    vector<Paciente> pacientes;

    ifstream archivo("pacientes.txt");

    if (archivo)
    {
        int idPaciente, edad;
        string nombre, apellido, email, telefono, DNI;

        while (archivo >> idPaciente)

        {
            archivo.ignore();
            getline(archivo, nombre, '|');
            getline(archivo, apellido, '|');
            archivo >> edad;
            archivo.ignore();
            getline(archivo, DNI, '|');
            getline(archivo, email, '|');
            getline(archivo, telefono);


            pacientes.push_back(Paciente(idPaciente, nombre, apellido, edad, DNI, email, telefono));
        }

        archivo.close();
    }

    return pacientes;
}

// ========== FUNCION MODIFICAR PACIENTES ============

void modificarPaciente(int id)
{
    bool pacienteEncontrado = false;
    vector<Paciente> pacientes = cargarPacientes();
    for (Paciente& p : pacientes)
    {
        if (p.idPaciente == id)
        {
            pacienteEncontrado = true;
            cout << "Ingrese nuevo nombre: ";
            cin >> p.nombre;
            cout << "Ingrese nuevo apellido: ";
            cin >> p.apellido;
            cout << "Ingrese nueva edad: ";
            cin >> p.edad;
            cout << "Ingrese nuevo DNI: ";
            cin >> p.DNI;
            cout << "Ingrese nuevo telefono: ";
            cin >> p.telefono;
            cout << "Ingrese nuevo email: ";
            cin >> p.email;

            ofstream archivo("pacientes.txt");
            for (const Paciente& p : pacientes)
            {
                archivo << p.idPaciente << "|" << p.nombre << "|" << p.apellido << "|" << p.edad << "|" << p.DNI << "|" << p.email << "|" << p.telefono << endl;
            }

           cout << "Paciente modificado exitosamente\n";
            break;
        }

    }

    if (!pacienteEncontrado)
    {
        cout << "Error: No se encontr� un paciente con el ID: " << id << endl;
    }

}

// ========== FUNCION ELIMINAR PACIENTES ==========

void eliminarPaciente(int id)
{
    bool pacienteEncontrado;
    vector<Paciente> pacientes = cargarPacientes();

    vector<Paciente> pacientesActualizados;

    for (const Paciente& p : pacientes)
    {
        if (p.idPaciente != id)
        {
            pacientesActualizados.push_back(p);
        }
        else
        {
            pacienteEncontrado = true;
        }
    }

    if (pacienteEncontrado)
    {
           ofstream archivo("pacientes.txt");
        for (const Paciente& p : pacientesActualizados)
        {
            archivo << p.idPaciente << "|" << p.nombre << "|" << p.apellido << "|" << p.edad << "|" << p.DNI << "|" << p.email << "|" << p.telefono << endl;  // Se escribe los doctores actualizados en el archivo
        cout << "Paciente eliminado exitosamente.\n" << endl;
        }
    }
    else
    {
        cout << "Error: No se encontr� un paciente con el ID: \n" << id << endl; // Mensaje de error si el doctor no existe
    }

}

// ========= FUNCION MOSTRAR DOCTORES ============

void mostrarPacientes()
{
    vector<Paciente> pacientes = cargarPacientes();

    for (const Paciente& p : pacientes)
    {
        p.info();
        cout << "----------------------------------" << endl;
    }
}


// ====== FUNCION PARA LIMPIAR PANTALLA =========
void limpiarPantalla()
{
    system ("cls");
}

// ======= Funcion para mostrar menu principal =========

void mostrarMenu()
{
    cout << "==================================================== MENU PRINCIPAL ====================================================\n" << endl;

    cout << "1. Doctores\n" << endl;
    cout << "2. Pacientes\n" << endl;
    cout << "3. Turnos\n" << endl;
    cout << "4. Salir\n" << endl;

}


// ======== PROGRAMA PRINCIPAL ==========

int main()
{
    setConsoleColors(11, 0);
    vector<Doctor> doctores;
    vector<Paciente> pacientes;
    vector<Turno> turnos;

    int opcion, opcion2, opcion3, opcion4;
    do
    {
        limpiarPantalla();
        mostrarMenu();


        cout << "Opcion: ";
        cin >> opcion;

        switch(opcion)
        {
            case 1:
                {
                    do
                    {
                        limpiarPantalla();
                        cout << "==================================================== MENU DOCTORES ====================================================\n" << endl;
                        cout << "1. Ver doctores\n" << endl;
                        cout << "2. Cargar doctor\n" << endl;
                        cout << "3. Modificar doctor\n" << endl;
                        cout << "4. Eliminar doctor\n" << endl;
                        cout << "5. Volver\n" << endl;
                        cout << "Opcion: ";
                        cin >> opcion2;

                        switch(opcion2)
                        {
                            case 1:
                                {
                                    limpiarPantalla();
                        cout << "==================================================== MENU DOCTORES ====================================================\n" << endl;

                                    mostrarDoctores();
                                    system("pause");
                                    break;
                                }

                            case 2:
                                {
                                    limpiarPantalla();
                                    int idDoctor, edad;
                                    string nombre, apellido, especialidad, DNI, telefono, email;
                                    cout << "==================================================== MENU DOCTORES ====================================================\n" << endl;

                                    cout << "Ingrese ID del doctor: \n";
                                    cin >> idDoctor;
                                    cout << "Ingrese nombre del doctor: \n";
                                    cin >> nombre;
                                    cout << "Ingrese apellido del doctor: \n";
                                    cin >> apellido;
                                    cout << "Ingrese especialidad del doctor: \n";
                                    cin >> especialidad;
                                    cout << "Ingrese DNI del doctor: \n";
                                    cin >> DNI;
                                    cout << "Ingrese edad del doctor: \n";
                                    cin >> edad;
                                    cout << "Ingrese telefono del doctor: \n";
                                    cin >> telefono;
                                    cout << "Ingrese email del doctor: \n";
                                    cin >> email;

                                    doctores.push_back(Doctor(idDoctor, nombre, apellido, especialidad, DNI,edad, telefono, email));
                                    doctores.back().guardarArchivo();

                                    cout << "Doctor a�adido exitosamente.";
                                    break;
                                }

                            case 3:
                                {
                                    limpiarPantalla();
                                    cout << "==================================================== MENU DOCTORES ====================================================\n" << endl;

                                     int id;
                                     cout << "Ingrese ID del doctor a modificar: ";
                                     cin >> id;
                                     modificarDoctor(id);

                                     system("pause");
                                     break;
                                }

                            case 4:
                                {
                                    limpiarPantalla();
                                    cout << "==================================================== MENU DOCTORES ====================================================\n" << endl;

                                    int id;
                                    cout << "Ingrese ID del doctor a eliminar: ";
                                    cin >> id;
                                    eliminarDoctor(id);

                                    system("pause");
                                    break;
                                }


                        }
                    } while (opcion2 != 5);
                 break;
                }

            case 2:
                {
                    do
                    {
                        limpiarPantalla();
                        cout << "==================================================== MENU PACIENTES ====================================================\n" << endl;
                        cout << "1. Ver pacientes\n" << endl;
                        cout << "2. Cargar pacientes\n" << endl;
                        cout << "3. Modificar pacientes\n" << endl;
                        cout << "4. Eliminar pacientes\n" << endl;
                        cout << "5. Volver\n" << endl;
                        cout << "Opcion: ";
                        cin >> opcion3;

                        switch(opcion3)
                        {
                            case 1:
                                {
                                    limpiarPantalla();
                                    cout << "==================================================== MENU PACIENTES ====================================================\n" << endl;
                                    mostrarPacientes();
                                    system("pause");
                                    break;
                                }

                            case 2:
                                {
                                    limpiarPantalla();
                                    int idPaciente, edad;
                                    string nombre, apellido,DNI, telefono, email;
                                    cout << "==================================================== MENU PACIENTES ====================================================\n" << endl;

                                    cout << "Ingrese ID del paciente: \n";
                                    cin >> idPaciente;
                                    cout << "Ingrese nombre del paciente: \n";
                                    cin >> nombre;
                                    cout << "Ingrese apellido del paciente: \n";
                                    cin >> apellido;
                                    cout << "Ingrese DNI del paciente: \n";
                                    cin >> DNI;
                                    cout << "Ingrese edad del paciente: \n";
                                    cin >> edad;
                                    cout << "Ingrese telefono del paciente: \n";
                                    cin >> telefono;
                                    cout << "Ingrese email del paciente: \n";
                                    cin >> email;

                                    pacientes.push_back(Paciente(idPaciente, nombre, apellido, edad, DNI, email, telefono));
                                    pacientes.back().guardarArchivo();

                                    cout << "Paciente a�adido exitosamente.";
                                    break;
                                }

                            case 3:
                                {
                                     limpiarPantalla();
                                    cout << "==================================================== MENU PACIENTES ====================================================\n" << endl;

                                     int id;
                                     cout << "Ingrese ID del paciente a modificar: ";
                                     cin >> id;
                                     modificarPaciente(id);

                                     system("pause");
                                     break;
                                }

                            case 4:
                                {
                                    limpiarPantalla();
                                    cout << "==================================================== MENU PACIENTES ====================================================\n" << endl;

                                    int id;
                                    cout << "Ingrese ID del paciente a eliminar: ";
                                    cin >> id;
                                    eliminarPaciente(id);

                                    system("pause");
                                    break;
                                }
                        }

                    } while (opcion3 != 5);
                 break;
                }

            case 3:
                {
                     do
                     {
                         limpiarPantalla();
                        cout << "==================================================== MENU TURNOS ====================================================\n" << endl;
                        cout << "1. Ver turnos\n" << endl;
                        cout << "2. Cargar turnos\n" << endl;
                        cout << "3. Modificar turnos\n" << endl;
                        cout << "4. Eliminar turnos\n" << endl;
                        cout << "5. Volver\n" << endl;
                        cout << "Opcion: ";
                        cin >> opcion4;

                        switch(opcion4)
                        {
                            case 1:
                                {
                                    limpiarPantalla();
                                    cout << "==================================================== MENU TURNOS ====================================================\n" << endl;
                                    mostrarTurnos();
                                    system("pause");
                                    break;
                                }

                            case 2:
                                {
                                    limpiarPantalla();
                                    int idTurno, idPaciente, idDoctor;
                                    string fecha;
                                    cout << "==================================================== MENU TURNOS ====================================================\n" << endl;

                                    cout << "Ingrese ID del turno: \n";
                                    cin >> idTurno;
                                    cout << "Ingrese ID del doctor: \n";
                                    cin >> idDoctor;
                                    cout << "Ingrese ID del paciente: \n";
                                    cin >> idPaciente;
                                    cout << "Ingrese fecha del turno: \n";
                                    cin >> fecha;

                                    turnos.push_back(Turno(idTurno, idDoctor, idPaciente, fecha));
                                    turnos.back().guardarArchivo();

                                    cout << "Turno a�adido exitosamente.";
                                    break;
                                }

                            case 3:
                                {
                                     limpiarPantalla();
                                    cout << "==================================================== MENU TURNOS ====================================================\n" << endl;

                                     int id;
                                     cout << "Ingrese ID del turno a modificar: ";
                                     cin >> id;
                                     modificarTurno(id);

                                     system("pause");
                                     break;
                                }

                            case 4:
                                {
                                     limpiarPantalla();
                                    cout << "==================================================== MENU TURNOS ====================================================\n" << endl;

                                    int id;
                                    cout << "Ingrese ID del turno a eliminar: ";
                                    cin >> id;
                                    eliminarTurno(id);

                                    system("pause");
                                    break;
                                }
                        }


                     } while(opcion4 != 4);
                 break;
                }
        }




      system("pause");
    } while (opcion != 4);

    return 0;
}

