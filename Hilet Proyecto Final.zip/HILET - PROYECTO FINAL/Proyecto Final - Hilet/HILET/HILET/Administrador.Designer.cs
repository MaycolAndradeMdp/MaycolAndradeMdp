﻿namespace HILET
{
    partial class Administrador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            tabControl1 = new TabControl();
            tpGestionProfesores = new TabPage();
            label57 = new Label();
            dtgProfesores = new DataGridView();
            btnBuscar = new Button();
            btnReporteProfesores = new Button();
            btnModificarProfesor = new Button();
            btnEliminarProfesor = new Button();
            btnAgregarProfesor = new Button();
            txtIDProfesor = new TextBox();
            txtContraseñaProfesor = new TextBox();
            txtUsuarioProfesor = new TextBox();
            txtEmailProfesor = new TextBox();
            txtTelefonoProfesor = new TextBox();
            txtDomicilioAlturaProfesor = new TextBox();
            txtDomicilioProfesor = new TextBox();
            txtDNIprofesor = new TextBox();
            txtApellidoProfesor = new TextBox();
            txtNombreProfesor = new TextBox();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            tpGestionExamenes = new TabPage();
            dtgNotasAdmin = new DataGridView();
            panel2 = new Panel();
            btnReportesExamenes = new Button();
            btnBuscarNota = new Button();
            txtMatriculaNota = new TextBox();
            txtDniNotaAdmin = new TextBox();
            txtApellidoNota = new TextBox();
            label22 = new Label();
            label19 = new Label();
            txtNombreNota = new TextBox();
            label20 = new Label();
            label21 = new Label();
            panel1 = new Panel();
            btnModificarNota = new Button();
            txtMatriculaExamenes = new TextBox();
            btnAgregarNota = new Button();
            txtFolio = new TextBox();
            txtLibro = new TextBox();
            txtNota = new TextBox();
            cmbInstanciaExamenes = new ComboBox();
            cmbMateriaExamenes = new ComboBox();
            label16 = new Label();
            label17 = new Label();
            label18 = new Label();
            label15 = new Label();
            label14 = new Label();
            label13 = new Label();
            label12 = new Label();
            tpGestionAlumnos = new TabPage();
            txtMatriculaAlumnos = new TextBox();
            label58 = new Label();
            txtEmailAlumno = new TextBox();
            txtContraseñaAlumno = new TextBox();
            txtUsuarioAlumno = new TextBox();
            txtTelefonAlumno = new TextBox();
            txtDomiciloAltAlumno = new TextBox();
            txtDomiciloAlumno = new TextBox();
            txtDNIalumno = new TextBox();
            txtApellidoAlumno = new TextBox();
            btnReporteAlumno = new Button();
            btnBuscarAlumno = new Button();
            btnModificarAlumno = new Button();
            btnEliminarAlumno = new Button();
            btnAgregarAlumno = new Button();
            dtgAlumnos = new DataGridView();
            cmbFiltroAlumnos = new ComboBox();
            label33 = new Label();
            label32 = new Label();
            txtNombreAlumno = new TextBox();
            label23 = new Label();
            label24 = new Label();
            label25 = new Label();
            label26 = new Label();
            label27 = new Label();
            label28 = new Label();
            label29 = new Label();
            label30 = new Label();
            label31 = new Label();
            tabPage4 = new TabPage();
            dtgCarrera = new DataGridView();
            panel5 = new Panel();
            btnBuscarCarreras = new Button();
            label45 = new Label();
            cmbVisualizarCarreras = new ComboBox();
            panel4 = new Panel();
            txtDuracion = new TextBox();
            btnEliminarCarrera = new Button();
            txtResolucion = new TextBox();
            btnAgregarCarrera = new Button();
            txtCarreraNombre = new TextBox();
            label39 = new Label();
            label38 = new Label();
            label35 = new Label();
            panel3 = new Panel();
            cmbProfesor = new ComboBox();
            cmbCarrera = new ComboBox();
            btnReporteCarrera = new Button();
            btnModificarMateria = new Button();
            btnEliminarMateria = new Button();
            txtIDmateria = new TextBox();
            btnAgregarMateria = new Button();
            txtAño = new TextBox();
            txtNombreMateria = new TextBox();
            label43 = new Label();
            label44 = new Label();
            label40 = new Label();
            label41 = new Label();
            label42 = new Label();
            label37 = new Label();
            label36 = new Label();
            label34 = new Label();
            tabGestionPersonal = new TabPage();
            btnReportePersonalAdmin = new Button();
            dtgPersonalAdministrativo = new DataGridView();
            btnBuscarAdmin = new Button();
            btnModificarPersonal = new Button();
            btnEliminarPersonal = new Button();
            btnAgregarPersonal = new Button();
            txtIDpersonal = new TextBox();
            label56 = new Label();
            txtDomicilioNumeroPersnonal = new TextBox();
            label46 = new Label();
            txtContraseñaPersonal = new TextBox();
            txtUsuarioPersonal = new TextBox();
            txtEmailPersonal = new TextBox();
            txtTelefonoPersonal = new TextBox();
            txtDomicilioCallePersonal = new TextBox();
            txtDNIpersnal = new TextBox();
            txtApellidoPersonal = new TextBox();
            txtNombrePersonal = new TextBox();
            label47 = new Label();
            label48 = new Label();
            label49 = new Label();
            label50 = new Label();
            label51 = new Label();
            label52 = new Label();
            label53 = new Label();
            label54 = new Label();
            label55 = new Label();
            error1 = new ErrorProvider(components);
            btnMinimizar = new Button();
            button1 = new Button();
            tabControl1.SuspendLayout();
            tpGestionProfesores.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dtgProfesores).BeginInit();
            tpGestionExamenes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dtgNotasAdmin).BeginInit();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            tpGestionAlumnos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dtgAlumnos).BeginInit();
            tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dtgCarrera).BeginInit();
            panel5.SuspendLayout();
            panel4.SuspendLayout();
            panel3.SuspendLayout();
            tabGestionPersonal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dtgPersonalAdministrativo).BeginInit();
            ((System.ComponentModel.ISupportInitialize)error1).BeginInit();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tpGestionProfesores);
            tabControl1.Controls.Add(tpGestionExamenes);
            tabControl1.Controls.Add(tpGestionAlumnos);
            tabControl1.Controls.Add(tabPage4);
            tabControl1.Controls.Add(tabGestionPersonal);
            tabControl1.Dock = DockStyle.Bottom;
            tabControl1.Location = new Point(0, 28);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1070, 498);
            tabControl1.TabIndex = 0;
            // 
            // tpGestionProfesores
            // 
            tpGestionProfesores.Controls.Add(label57);
            tpGestionProfesores.Controls.Add(dtgProfesores);
            tpGestionProfesores.Controls.Add(btnBuscar);
            tpGestionProfesores.Controls.Add(btnReporteProfesores);
            tpGestionProfesores.Controls.Add(btnModificarProfesor);
            tpGestionProfesores.Controls.Add(btnEliminarProfesor);
            tpGestionProfesores.Controls.Add(btnAgregarProfesor);
            tpGestionProfesores.Controls.Add(txtIDProfesor);
            tpGestionProfesores.Controls.Add(txtContraseñaProfesor);
            tpGestionProfesores.Controls.Add(txtUsuarioProfesor);
            tpGestionProfesores.Controls.Add(txtEmailProfesor);
            tpGestionProfesores.Controls.Add(txtTelefonoProfesor);
            tpGestionProfesores.Controls.Add(txtDomicilioAlturaProfesor);
            tpGestionProfesores.Controls.Add(txtDomicilioProfesor);
            tpGestionProfesores.Controls.Add(txtDNIprofesor);
            tpGestionProfesores.Controls.Add(txtApellidoProfesor);
            tpGestionProfesores.Controls.Add(txtNombreProfesor);
            tpGestionProfesores.Controls.Add(label9);
            tpGestionProfesores.Controls.Add(label10);
            tpGestionProfesores.Controls.Add(label11);
            tpGestionProfesores.Controls.Add(label6);
            tpGestionProfesores.Controls.Add(label7);
            tpGestionProfesores.Controls.Add(label8);
            tpGestionProfesores.Controls.Add(label5);
            tpGestionProfesores.Controls.Add(label4);
            tpGestionProfesores.Controls.Add(label3);
            tpGestionProfesores.Controls.Add(label2);
            tpGestionProfesores.Controls.Add(label1);
            tpGestionProfesores.Location = new Point(4, 24);
            tpGestionProfesores.Name = "tpGestionProfesores";
            tpGestionProfesores.Padding = new Padding(3);
            tpGestionProfesores.Size = new Size(1062, 470);
            tpGestionProfesores.TabIndex = 0;
            tpGestionProfesores.Text = "Gestion Profesores";
            tpGestionProfesores.UseVisualStyleBackColor = true;
            // 
            // label57
            // 
            label57.AutoSize = true;
            label57.BackColor = Color.Transparent;
            label57.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label57.ForeColor = Color.FromArgb(255, 128, 0);
            label57.ImageAlign = ContentAlignment.MiddleLeft;
            label57.Location = new Point(9, 73);
            label57.Name = "label57";
            label57.Size = new Size(473, 16);
            label57.TabIndex = 191;
            label57.Text = "El campo de ID se llena solamente si se va a modificar/eliminar algún profesor";
            // 
            // dtgProfesores
            // 
            dtgProfesores.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgProfesores.Location = new Point(9, 376);
            dtgProfesores.Name = "dtgProfesores";
            dtgProfesores.Size = new Size(1045, 114);
            dtgProfesores.TabIndex = 46;
            // 
            // btnBuscar
            // 
            btnBuscar.Location = new Point(660, 337);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new Size(210, 33);
            btnBuscar.TabIndex = 45;
            btnBuscar.Text = "Buscar";
            btnBuscar.UseVisualStyleBackColor = true;
            btnBuscar.Click += btnBuscar_Click;
            // 
            // btnReporteProfesores
            // 
            btnReporteProfesores.Location = new Point(954, 337);
            btnReporteProfesores.Name = "btnReporteProfesores";
            btnReporteProfesores.Size = new Size(100, 33);
            btnReporteProfesores.TabIndex = 44;
            btnReporteProfesores.Text = "Reporte";
            btnReporteProfesores.UseVisualStyleBackColor = true;
            btnReporteProfesores.Click += btnReporteProfesores_Click;
            // 
            // btnModificarProfesor
            // 
            btnModificarProfesor.Location = new Point(98, 293);
            btnModificarProfesor.Name = "btnModificarProfesor";
            btnModificarProfesor.Size = new Size(67, 33);
            btnModificarProfesor.TabIndex = 43;
            btnModificarProfesor.Text = "Modificar";
            btnModificarProfesor.UseVisualStyleBackColor = true;
            btnModificarProfesor.Click += btnModificarProfesor_Click;
            // 
            // btnEliminarProfesor
            // 
            btnEliminarProfesor.Location = new Point(171, 293);
            btnEliminarProfesor.Name = "btnEliminarProfesor";
            btnEliminarProfesor.Size = new Size(67, 33);
            btnEliminarProfesor.TabIndex = 42;
            btnEliminarProfesor.Text = "Eliminar";
            btnEliminarProfesor.UseVisualStyleBackColor = true;
            btnEliminarProfesor.Click += btnEliminarProfesor_Click;
            // 
            // btnAgregarProfesor
            // 
            btnAgregarProfesor.Location = new Point(25, 293);
            btnAgregarProfesor.Name = "btnAgregarProfesor";
            btnAgregarProfesor.Size = new Size(67, 33);
            btnAgregarProfesor.TabIndex = 41;
            btnAgregarProfesor.Text = "Agregar";
            btnAgregarProfesor.UseVisualStyleBackColor = true;
            btnAgregarProfesor.Click += btnAgregarProfesor_Click;
            // 
            // txtIDProfesor
            // 
            txtIDProfesor.Location = new Point(99, 103);
            txtIDProfesor.Name = "txtIDProfesor";
            txtIDProfesor.Size = new Size(124, 23);
            txtIDProfesor.TabIndex = 40;
            // 
            // txtContraseñaProfesor
            // 
            txtContraseñaProfesor.Location = new Point(635, 190);
            txtContraseñaProfesor.Name = "txtContraseñaProfesor";
            txtContraseñaProfesor.Size = new Size(124, 23);
            txtContraseñaProfesor.TabIndex = 39;
            // 
            // txtUsuarioProfesor
            // 
            txtUsuarioProfesor.Location = new Point(635, 145);
            txtUsuarioProfesor.Name = "txtUsuarioProfesor";
            txtUsuarioProfesor.Size = new Size(124, 23);
            txtUsuarioProfesor.TabIndex = 38;
            // 
            // txtEmailProfesor
            // 
            txtEmailProfesor.Location = new Point(635, 100);
            txtEmailProfesor.Name = "txtEmailProfesor";
            txtEmailProfesor.Size = new Size(124, 23);
            txtEmailProfesor.TabIndex = 37;
            // 
            // txtTelefonoProfesor
            // 
            txtTelefonoProfesor.Location = new Point(358, 193);
            txtTelefonoProfesor.Name = "txtTelefonoProfesor";
            txtTelefonoProfesor.Size = new Size(124, 23);
            txtTelefonoProfesor.TabIndex = 36;
            // 
            // txtDomicilioAlturaProfesor
            // 
            txtDomicilioAlturaProfesor.Location = new Point(358, 145);
            txtDomicilioAlturaProfesor.Name = "txtDomicilioAlturaProfesor";
            txtDomicilioAlturaProfesor.Size = new Size(124, 23);
            txtDomicilioAlturaProfesor.TabIndex = 35;
            // 
            // txtDomicilioProfesor
            // 
            txtDomicilioProfesor.Location = new Point(358, 103);
            txtDomicilioProfesor.Name = "txtDomicilioProfesor";
            txtDomicilioProfesor.Size = new Size(124, 23);
            txtDomicilioProfesor.TabIndex = 34;
            // 
            // txtDNIprofesor
            // 
            txtDNIprofesor.Location = new Point(99, 238);
            txtDNIprofesor.Name = "txtDNIprofesor";
            txtDNIprofesor.Size = new Size(124, 23);
            txtDNIprofesor.TabIndex = 33;
            // 
            // txtApellidoProfesor
            // 
            txtApellidoProfesor.Location = new Point(99, 190);
            txtApellidoProfesor.Name = "txtApellidoProfesor";
            txtApellidoProfesor.Size = new Size(124, 23);
            txtApellidoProfesor.TabIndex = 32;
            // 
            // txtNombreProfesor
            // 
            txtNombreProfesor.Location = new Point(99, 145);
            txtNombreProfesor.Name = "txtNombreProfesor";
            txtNombreProfesor.Size = new Size(124, 23);
            txtNombreProfesor.TabIndex = 31;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(58, 106);
            label9.Name = "label9";
            label9.Size = new Size(18, 15);
            label9.TabIndex = 30;
            label9.Text = "ID";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(554, 197);
            label10.Name = "label10";
            label10.Size = new Size(67, 15);
            label10.TabIndex = 29;
            label10.Text = "Contraseña";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(574, 148);
            label11.Name = "label11";
            label11.Size = new Size(47, 15);
            label11.TabIndex = 28;
            label11.Text = "Usuario";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(574, 103);
            label6.Name = "label6";
            label6.Size = new Size(36, 15);
            label6.TabIndex = 27;
            label6.Text = "Email";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(297, 193);
            label7.Name = "label7";
            label7.Size = new Size(52, 15);
            label7.TabIndex = 26;
            label7.Text = "Telefono";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(261, 148);
            label8.Name = "label8";
            label8.Size = new Size(91, 15);
            label8.TabIndex = 25;
            label8.Text = "Domicilio altura";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(296, 106);
            label5.Name = "label5";
            label5.Size = new Size(58, 15);
            label5.TabIndex = 24;
            label5.Text = "Domicilio";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(42, 241);
            label4.Name = "label4";
            label4.Size = new Size(25, 15);
            label4.TabIndex = 23;
            label4.Text = "Dni";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(42, 193);
            label3.Name = "label3";
            label3.Size = new Size(51, 15);
            label3.TabIndex = 22;
            label3.Text = "Apellido";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(42, 148);
            label2.Name = "label2";
            label2.Size = new Size(51, 15);
            label2.TabIndex = 21;
            label2.Text = "Nombre";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 21.75F);
            label1.Location = new Point(420, 12);
            label1.Name = "label1";
            label1.Size = new Size(228, 40);
            label1.TabIndex = 20;
            label1.Text = "Gestion Profesor";
            // 
            // tpGestionExamenes
            // 
            tpGestionExamenes.Controls.Add(dtgNotasAdmin);
            tpGestionExamenes.Controls.Add(panel2);
            tpGestionExamenes.Controls.Add(panel1);
            tpGestionExamenes.Controls.Add(label12);
            tpGestionExamenes.Location = new Point(4, 24);
            tpGestionExamenes.Name = "tpGestionExamenes";
            tpGestionExamenes.Padding = new Padding(3);
            tpGestionExamenes.Size = new Size(1062, 470);
            tpGestionExamenes.TabIndex = 1;
            tpGestionExamenes.Text = "Gestion examenes";
            tpGestionExamenes.UseVisualStyleBackColor = true;
            // 
            // dtgNotasAdmin
            // 
            dtgNotasAdmin.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgNotasAdmin.Location = new Point(8, 345);
            dtgNotasAdmin.Name = "dtgNotasAdmin";
            dtgNotasAdmin.Size = new Size(1045, 150);
            dtgNotasAdmin.TabIndex = 24;
            dtgNotasAdmin.CellDoubleClick += dtgNotasAdmin_CellDoubleClick;
            // 
            // panel2
            // 
            panel2.Controls.Add(btnReportesExamenes);
            panel2.Controls.Add(btnBuscarNota);
            panel2.Controls.Add(txtMatriculaNota);
            panel2.Controls.Add(txtDniNotaAdmin);
            panel2.Controls.Add(txtApellidoNota);
            panel2.Controls.Add(label22);
            panel2.Controls.Add(label19);
            panel2.Controls.Add(txtNombreNota);
            panel2.Controls.Add(label20);
            panel2.Controls.Add(label21);
            panel2.Location = new Point(603, 104);
            panel2.Name = "panel2";
            panel2.Size = new Size(252, 227);
            panel2.TabIndex = 23;
            // 
            // btnReportesExamenes
            // 
            btnReportesExamenes.Location = new Point(133, 187);
            btnReportesExamenes.Name = "btnReportesExamenes";
            btnReportesExamenes.Size = new Size(100, 33);
            btnReportesExamenes.TabIndex = 47;
            btnReportesExamenes.Text = "Reporte";
            btnReportesExamenes.UseVisualStyleBackColor = true;
            btnReportesExamenes.Click += btnReportesExamenes_Click;
            // 
            // btnBuscarNota
            // 
            btnBuscarNota.Location = new Point(27, 187);
            btnBuscarNota.Name = "btnBuscarNota";
            btnBuscarNota.Size = new Size(100, 33);
            btnBuscarNota.TabIndex = 46;
            btnBuscarNota.Text = "Buscar";
            btnBuscarNota.UseVisualStyleBackColor = true;
            btnBuscarNota.Click += btnBuscarNota_Click;
            // 
            // txtMatriculaNota
            // 
            txtMatriculaNota.Location = new Point(89, 129);
            txtMatriculaNota.Name = "txtMatriculaNota";
            txtMatriculaNota.Size = new Size(100, 23);
            txtMatriculaNota.TabIndex = 13;
            // 
            // txtDniNotaAdmin
            // 
            txtDniNotaAdmin.Location = new Point(89, 95);
            txtDniNotaAdmin.Name = "txtDniNotaAdmin";
            txtDniNotaAdmin.Size = new Size(100, 23);
            txtDniNotaAdmin.TabIndex = 12;
            // 
            // txtApellidoNota
            // 
            txtApellidoNota.Location = new Point(89, 66);
            txtApellidoNota.Name = "txtApellidoNota";
            txtApellidoNota.Size = new Size(100, 23);
            txtApellidoNota.TabIndex = 11;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(21, 129);
            label22.Name = "label22";
            label22.Size = new Size(57, 15);
            label22.TabIndex = 9;
            label22.Text = "Matricula";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(51, 98);
            label19.Name = "label19";
            label19.Size = new Size(27, 15);
            label19.TabIndex = 8;
            label19.Text = "DNI";
            // 
            // txtNombreNota
            // 
            txtNombreNota.Location = new Point(89, 32);
            txtNombreNota.Name = "txtNombreNota";
            txtNombreNota.Size = new Size(100, 23);
            txtNombreNota.TabIndex = 10;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(27, 66);
            label20.Name = "label20";
            label20.Size = new Size(51, 15);
            label20.TabIndex = 7;
            label20.Text = "Apellido";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(27, 32);
            label21.Name = "label21";
            label21.Size = new Size(51, 15);
            label21.TabIndex = 6;
            label21.Text = "Nombre";
            // 
            // panel1
            // 
            panel1.Controls.Add(btnModificarNota);
            panel1.Controls.Add(txtMatriculaExamenes);
            panel1.Controls.Add(btnAgregarNota);
            panel1.Controls.Add(txtFolio);
            panel1.Controls.Add(txtLibro);
            panel1.Controls.Add(txtNota);
            panel1.Controls.Add(cmbInstanciaExamenes);
            panel1.Controls.Add(cmbMateriaExamenes);
            panel1.Controls.Add(label16);
            panel1.Controls.Add(label17);
            panel1.Controls.Add(label18);
            panel1.Controls.Add(label15);
            panel1.Controls.Add(label14);
            panel1.Controls.Add(label13);
            panel1.Location = new Point(34, 104);
            panel1.Name = "panel1";
            panel1.Size = new Size(409, 227);
            panel1.TabIndex = 22;
            // 
            // btnModificarNota
            // 
            btnModificarNota.Location = new Point(117, 187);
            btnModificarNota.Name = "btnModificarNota";
            btnModificarNota.Size = new Size(100, 33);
            btnModificarNota.TabIndex = 45;
            btnModificarNota.Text = "Modificar";
            btnModificarNota.UseVisualStyleBackColor = true;
            btnModificarNota.Click += btnModificarNota_Click;
            // 
            // txtMatriculaExamenes
            // 
            txtMatriculaExamenes.Location = new Point(272, 132);
            txtMatriculaExamenes.Name = "txtMatriculaExamenes";
            txtMatriculaExamenes.Size = new Size(100, 23);
            txtMatriculaExamenes.TabIndex = 11;
            // 
            // btnAgregarNota
            // 
            btnAgregarNota.Location = new Point(11, 187);
            btnAgregarNota.Name = "btnAgregarNota";
            btnAgregarNota.Size = new Size(100, 33);
            btnAgregarNota.TabIndex = 44;
            btnAgregarNota.Text = "Agregar";
            btnAgregarNota.UseVisualStyleBackColor = true;
            btnAgregarNota.Click += btnAgregarNota_Click;
            // 
            // txtFolio
            // 
            txtFolio.Location = new Point(83, 126);
            txtFolio.Name = "txtFolio";
            txtFolio.Size = new Size(100, 23);
            txtFolio.TabIndex = 10;
            // 
            // txtLibro
            // 
            txtLibro.Location = new Point(272, 35);
            txtLibro.Name = "txtLibro";
            txtLibro.Size = new Size(100, 23);
            txtLibro.TabIndex = 9;
            // 
            // txtNota
            // 
            txtNota.Location = new Point(83, 35);
            txtNota.Name = "txtNota";
            txtNota.Size = new Size(100, 23);
            txtNota.TabIndex = 8;
            // 
            // cmbInstanciaExamenes
            // 
            cmbInstanciaExamenes.FormattingEnabled = true;
            cmbInstanciaExamenes.Location = new Point(272, 76);
            cmbInstanciaExamenes.Name = "cmbInstanciaExamenes";
            cmbInstanciaExamenes.Size = new Size(100, 23);
            cmbInstanciaExamenes.TabIndex = 7;
            cmbInstanciaExamenes.DropDown += cmbInstanciaExamenes_DropDown;
            // 
            // cmbMateriaExamenes
            // 
            cmbMateriaExamenes.FormattingEnabled = true;
            cmbMateriaExamenes.Location = new Point(83, 79);
            cmbMateriaExamenes.Name = "cmbMateriaExamenes";
            cmbMateriaExamenes.Size = new Size(100, 23);
            cmbMateriaExamenes.TabIndex = 6;
            cmbMateriaExamenes.DropDown += cmbMateriaExamenes_DropDown;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(209, 132);
            label16.Name = "label16";
            label16.Size = new Size(57, 15);
            label16.TabIndex = 5;
            label16.Text = "Matricula";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(209, 84);
            label17.Name = "label17";
            label17.Size = new Size(54, 15);
            label17.TabIndex = 4;
            label17.Text = "Instancia";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(222, 38);
            label18.Name = "label18";
            label18.Size = new Size(34, 15);
            label18.TabIndex = 3;
            label18.Text = "Libro";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(31, 129);
            label15.Name = "label15";
            label15.Size = new Size(33, 15);
            label15.TabIndex = 2;
            label15.Text = "Folio";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(31, 79);
            label14.Name = "label14";
            label14.Size = new Size(47, 15);
            label14.TabIndex = 1;
            label14.Text = "Materia";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(31, 35);
            label13.Name = "label13";
            label13.Size = new Size(33, 15);
            label13.TabIndex = 0;
            label13.Text = "Nota";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 21.75F);
            label12.Location = new Point(421, 35);
            label12.Name = "label12";
            label12.Size = new Size(248, 40);
            label12.TabIndex = 21;
            label12.Text = "Gestion Examenes";
            // 
            // tpGestionAlumnos
            // 
            tpGestionAlumnos.Controls.Add(txtMatriculaAlumnos);
            tpGestionAlumnos.Controls.Add(label58);
            tpGestionAlumnos.Controls.Add(txtEmailAlumno);
            tpGestionAlumnos.Controls.Add(txtContraseñaAlumno);
            tpGestionAlumnos.Controls.Add(txtUsuarioAlumno);
            tpGestionAlumnos.Controls.Add(txtTelefonAlumno);
            tpGestionAlumnos.Controls.Add(txtDomiciloAltAlumno);
            tpGestionAlumnos.Controls.Add(txtDomiciloAlumno);
            tpGestionAlumnos.Controls.Add(txtDNIalumno);
            tpGestionAlumnos.Controls.Add(txtApellidoAlumno);
            tpGestionAlumnos.Controls.Add(btnReporteAlumno);
            tpGestionAlumnos.Controls.Add(btnBuscarAlumno);
            tpGestionAlumnos.Controls.Add(btnModificarAlumno);
            tpGestionAlumnos.Controls.Add(btnEliminarAlumno);
            tpGestionAlumnos.Controls.Add(btnAgregarAlumno);
            tpGestionAlumnos.Controls.Add(dtgAlumnos);
            tpGestionAlumnos.Controls.Add(cmbFiltroAlumnos);
            tpGestionAlumnos.Controls.Add(label33);
            tpGestionAlumnos.Controls.Add(label32);
            tpGestionAlumnos.Controls.Add(txtNombreAlumno);
            tpGestionAlumnos.Controls.Add(label23);
            tpGestionAlumnos.Controls.Add(label24);
            tpGestionAlumnos.Controls.Add(label25);
            tpGestionAlumnos.Controls.Add(label26);
            tpGestionAlumnos.Controls.Add(label27);
            tpGestionAlumnos.Controls.Add(label28);
            tpGestionAlumnos.Controls.Add(label29);
            tpGestionAlumnos.Controls.Add(label30);
            tpGestionAlumnos.Controls.Add(label31);
            tpGestionAlumnos.Location = new Point(4, 24);
            tpGestionAlumnos.Name = "tpGestionAlumnos";
            tpGestionAlumnos.Padding = new Padding(3);
            tpGestionAlumnos.Size = new Size(1062, 470);
            tpGestionAlumnos.TabIndex = 2;
            tpGestionAlumnos.Text = "Gestion Alumnos";
            tpGestionAlumnos.UseVisualStyleBackColor = true;
            // 
            // txtMatriculaAlumnos
            // 
            txtMatriculaAlumnos.Location = new Point(878, 156);
            txtMatriculaAlumnos.Name = "txtMatriculaAlumnos";
            txtMatriculaAlumnos.Size = new Size(124, 23);
            txtMatriculaAlumnos.TabIndex = 78;
            // 
            // label58
            // 
            label58.AutoSize = true;
            label58.Location = new Point(811, 159);
            label58.Name = "label58";
            label58.Size = new Size(57, 15);
            label58.TabIndex = 77;
            label58.Text = "Matricula";
            // 
            // txtEmailAlumno
            // 
            txtEmailAlumno.Location = new Point(645, 204);
            txtEmailAlumno.Name = "txtEmailAlumno";
            txtEmailAlumno.Size = new Size(124, 23);
            txtEmailAlumno.TabIndex = 76;
            // 
            // txtContraseñaAlumno
            // 
            txtContraseñaAlumno.Location = new Point(645, 157);
            txtContraseñaAlumno.Name = "txtContraseñaAlumno";
            txtContraseñaAlumno.Size = new Size(124, 23);
            txtContraseñaAlumno.TabIndex = 75;
            // 
            // txtUsuarioAlumno
            // 
            txtUsuarioAlumno.Location = new Point(645, 108);
            txtUsuarioAlumno.Name = "txtUsuarioAlumno";
            txtUsuarioAlumno.Size = new Size(124, 23);
            txtUsuarioAlumno.TabIndex = 74;
            // 
            // txtTelefonAlumno
            // 
            txtTelefonAlumno.Location = new Point(389, 204);
            txtTelefonAlumno.Name = "txtTelefonAlumno";
            txtTelefonAlumno.Size = new Size(124, 23);
            txtTelefonAlumno.TabIndex = 73;
            // 
            // txtDomiciloAltAlumno
            // 
            txtDomiciloAltAlumno.Location = new Point(389, 152);
            txtDomiciloAltAlumno.Name = "txtDomiciloAltAlumno";
            txtDomiciloAltAlumno.Size = new Size(124, 23);
            txtDomiciloAltAlumno.TabIndex = 72;
            // 
            // txtDomiciloAlumno
            // 
            txtDomiciloAlumno.Location = new Point(389, 108);
            txtDomiciloAlumno.Name = "txtDomiciloAlumno";
            txtDomiciloAlumno.Size = new Size(124, 23);
            txtDomiciloAlumno.TabIndex = 71;
            // 
            // txtDNIalumno
            // 
            txtDNIalumno.Location = new Point(120, 201);
            txtDNIalumno.Name = "txtDNIalumno";
            txtDNIalumno.Size = new Size(124, 23);
            txtDNIalumno.TabIndex = 70;
            // 
            // txtApellidoAlumno
            // 
            txtApellidoAlumno.Location = new Point(120, 153);
            txtApellidoAlumno.Name = "txtApellidoAlumno";
            txtApellidoAlumno.Size = new Size(124, 23);
            txtApellidoAlumno.TabIndex = 69;
            // 
            // btnReporteAlumno
            // 
            btnReporteAlumno.Location = new Point(954, 301);
            btnReporteAlumno.Name = "btnReporteAlumno";
            btnReporteAlumno.Size = new Size(100, 33);
            btnReporteAlumno.TabIndex = 68;
            btnReporteAlumno.Text = "Reporte";
            btnReporteAlumno.UseVisualStyleBackColor = true;
            btnReporteAlumno.Click += btnReporteAlumno_Click;
            // 
            // btnBuscarAlumno
            // 
            btnBuscarAlumno.Location = new Point(21, 301);
            btnBuscarAlumno.Name = "btnBuscarAlumno";
            btnBuscarAlumno.Size = new Size(213, 33);
            btnBuscarAlumno.TabIndex = 67;
            btnBuscarAlumno.Text = "Buscar";
            btnBuscarAlumno.UseVisualStyleBackColor = true;
            btnBuscarAlumno.Click += btnBuscarAlumno_Click;
            // 
            // btnModificarAlumno
            // 
            btnModificarAlumno.Location = new Point(94, 262);
            btnModificarAlumno.Name = "btnModificarAlumno";
            btnModificarAlumno.Size = new Size(67, 33);
            btnModificarAlumno.TabIndex = 66;
            btnModificarAlumno.Text = "Modificar";
            btnModificarAlumno.UseVisualStyleBackColor = true;
            btnModificarAlumno.Click += btnModificarAlumno_Click;
            // 
            // btnEliminarAlumno
            // 
            btnEliminarAlumno.Location = new Point(167, 262);
            btnEliminarAlumno.Name = "btnEliminarAlumno";
            btnEliminarAlumno.Size = new Size(67, 33);
            btnEliminarAlumno.TabIndex = 65;
            btnEliminarAlumno.Text = "Eliminar";
            btnEliminarAlumno.UseVisualStyleBackColor = true;
            btnEliminarAlumno.Click += btnEliminarAlumno_Click;
            // 
            // btnAgregarAlumno
            // 
            btnAgregarAlumno.Location = new Point(21, 262);
            btnAgregarAlumno.Name = "btnAgregarAlumno";
            btnAgregarAlumno.Size = new Size(67, 33);
            btnAgregarAlumno.TabIndex = 64;
            btnAgregarAlumno.Text = "Agregar";
            btnAgregarAlumno.UseVisualStyleBackColor = true;
            btnAgregarAlumno.Click += btnAgregarAlumno_Click;
            // 
            // dtgAlumnos
            // 
            dtgAlumnos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgAlumnos.Location = new Point(11, 340);
            dtgAlumnos.Name = "dtgAlumnos";
            dtgAlumnos.Size = new Size(1045, 150);
            dtgAlumnos.TabIndex = 63;
            dtgAlumnos.CellDoubleClick += dtgAlumnos_CellDoubleClick;
            // 
            // cmbFiltroAlumnos
            // 
            cmbFiltroAlumnos.FormattingEnabled = true;
            cmbFiltroAlumnos.Location = new Point(874, 108);
            cmbFiltroAlumnos.Name = "cmbFiltroAlumnos";
            cmbFiltroAlumnos.Size = new Size(161, 23);
            cmbFiltroAlumnos.TabIndex = 62;
            cmbFiltroAlumnos.DropDown += cmbFiltroAlumnos_DropDown;
            // 
            // label33
            // 
            label33.AutoSize = true;
            label33.Location = new Point(312, 111);
            label33.Name = "label33";
            label33.Size = new Size(58, 15);
            label33.TabIndex = 60;
            label33.Text = "Domicilio";
            // 
            // label32
            // 
            label32.AutoSize = true;
            label32.Font = new Font("Segoe UI", 21.75F);
            label32.Location = new Point(402, 28);
            label32.Name = "label32";
            label32.Size = new Size(234, 40);
            label32.TabIndex = 59;
            label32.Text = "Gestion Alumnos";
            // 
            // txtNombreAlumno
            // 
            txtNombreAlumno.Location = new Point(120, 108);
            txtNombreAlumno.Name = "txtNombreAlumno";
            txtNombreAlumno.Size = new Size(124, 23);
            txtNombreAlumno.TabIndex = 50;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new Point(807, 111);
            label23.Name = "label23";
            label23.Size = new Size(61, 15);
            label23.TabIndex = 49;
            label23.Text = "Filtrar por:";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Location = new Point(572, 160);
            label24.Name = "label24";
            label24.Size = new Size(67, 15);
            label24.TabIndex = 48;
            label24.Text = "Contraseña";
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Location = new Point(592, 111);
            label25.Name = "label25";
            label25.Size = new Size(47, 15);
            label25.TabIndex = 47;
            label25.Text = "Usuario";
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Location = new Point(592, 207);
            label26.Name = "label26";
            label26.Size = new Size(36, 15);
            label26.TabIndex = 46;
            label26.Text = "Email";
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Location = new Point(312, 207);
            label27.Name = "label27";
            label27.Size = new Size(52, 15);
            label27.TabIndex = 45;
            label27.Text = "Telefono";
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Location = new Point(276, 156);
            label28.Name = "label28";
            label28.Size = new Size(91, 15);
            label28.TabIndex = 44;
            label28.Text = "Domicilio altura";
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.Location = new Point(63, 204);
            label29.Name = "label29";
            label29.Size = new Size(25, 15);
            label29.TabIndex = 43;
            label29.Text = "Dni";
            // 
            // label30
            // 
            label30.AutoSize = true;
            label30.Location = new Point(63, 156);
            label30.Name = "label30";
            label30.Size = new Size(51, 15);
            label30.TabIndex = 42;
            label30.Text = "Apellido";
            // 
            // label31
            // 
            label31.AutoSize = true;
            label31.Location = new Point(63, 111);
            label31.Name = "label31";
            label31.Size = new Size(51, 15);
            label31.TabIndex = 41;
            label31.Text = "Nombre";
            // 
            // tabPage4
            // 
            tabPage4.Controls.Add(dtgCarrera);
            tabPage4.Controls.Add(panel5);
            tabPage4.Controls.Add(panel4);
            tabPage4.Controls.Add(panel3);
            tabPage4.Controls.Add(label37);
            tabPage4.Controls.Add(label36);
            tabPage4.Controls.Add(label34);
            tabPage4.Location = new Point(4, 24);
            tabPage4.Name = "tabPage4";
            tabPage4.Padding = new Padding(3);
            tabPage4.Size = new Size(1062, 470);
            tabPage4.TabIndex = 3;
            tabPage4.Text = "Gestion carreras";
            tabPage4.UseVisualStyleBackColor = true;
            // 
            // dtgCarrera
            // 
            dtgCarrera.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgCarrera.Location = new Point(9, 342);
            dtgCarrera.Name = "dtgCarrera";
            dtgCarrera.Size = new Size(1045, 150);
            dtgCarrera.TabIndex = 65;
            // 
            // panel5
            // 
            panel5.Controls.Add(btnBuscarCarreras);
            panel5.Controls.Add(label45);
            panel5.Controls.Add(cmbVisualizarCarreras);
            panel5.Location = new Point(777, 86);
            panel5.Name = "panel5";
            panel5.Size = new Size(274, 213);
            panel5.TabIndex = 64;
            // 
            // btnBuscarCarreras
            // 
            btnBuscarCarreras.Location = new Point(86, 130);
            btnBuscarCarreras.Name = "btnBuscarCarreras";
            btnBuscarCarreras.Size = new Size(114, 33);
            btnBuscarCarreras.TabIndex = 68;
            btnBuscarCarreras.Text = "Buscar";
            btnBuscarCarreras.UseVisualStyleBackColor = true;
            btnBuscarCarreras.Click += btnBuscarCarreras_Click;
            // 
            // label45
            // 
            label45.AutoSize = true;
            label45.Location = new Point(27, 78);
            label45.Name = "label45";
            label45.Size = new Size(45, 15);
            label45.TabIndex = 8;
            label45.Text = "Carrera";
            // 
            // cmbVisualizarCarreras
            // 
            cmbVisualizarCarreras.FormattingEnabled = true;
            cmbVisualizarCarreras.Location = new Point(86, 75);
            cmbVisualizarCarreras.Name = "cmbVisualizarCarreras";
            cmbVisualizarCarreras.Size = new Size(124, 23);
            cmbVisualizarCarreras.TabIndex = 0;
            // 
            // panel4
            // 
            panel4.Controls.Add(txtDuracion);
            panel4.Controls.Add(btnEliminarCarrera);
            panel4.Controls.Add(txtResolucion);
            panel4.Controls.Add(btnAgregarCarrera);
            panel4.Controls.Add(txtCarreraNombre);
            panel4.Controls.Add(label39);
            panel4.Controls.Add(label38);
            panel4.Controls.Add(label35);
            panel4.Location = new Point(27, 86);
            panel4.Name = "panel4";
            panel4.Size = new Size(239, 213);
            panel4.TabIndex = 64;
            // 
            // txtDuracion
            // 
            txtDuracion.Location = new Point(90, 106);
            txtDuracion.Name = "txtDuracion";
            txtDuracion.Size = new Size(124, 23);
            txtDuracion.TabIndex = 5;
            // 
            // btnEliminarCarrera
            // 
            btnEliminarCarrera.Location = new Point(90, 171);
            btnEliminarCarrera.Name = "btnEliminarCarrera";
            btnEliminarCarrera.Size = new Size(67, 33);
            btnEliminarCarrera.TabIndex = 68;
            btnEliminarCarrera.Text = "Eliminar";
            btnEliminarCarrera.UseVisualStyleBackColor = true;
            btnEliminarCarrera.Click += btnEliminarCarrera_Click;
            // 
            // txtResolucion
            // 
            txtResolucion.Location = new Point(90, 68);
            txtResolucion.Name = "txtResolucion";
            txtResolucion.Size = new Size(124, 23);
            txtResolucion.TabIndex = 4;
            // 
            // btnAgregarCarrera
            // 
            btnAgregarCarrera.Location = new Point(13, 171);
            btnAgregarCarrera.Name = "btnAgregarCarrera";
            btnAgregarCarrera.Size = new Size(67, 33);
            btnAgregarCarrera.TabIndex = 67;
            btnAgregarCarrera.Text = "Agregar";
            btnAgregarCarrera.UseVisualStyleBackColor = true;
            btnAgregarCarrera.Click += btnAgregarCarrera_Click;
            // 
            // txtCarreraNombre
            // 
            txtCarreraNombre.Location = new Point(90, 33);
            txtCarreraNombre.Name = "txtCarreraNombre";
            txtCarreraNombre.Size = new Size(124, 23);
            txtCarreraNombre.TabIndex = 3;
            // 
            // label39
            // 
            label39.AutoSize = true;
            label39.Location = new Point(25, 109);
            label39.Name = "label39";
            label39.Size = new Size(55, 15);
            label39.TabIndex = 2;
            label39.Text = "Duracion";
            // 
            // label38
            // 
            label38.AutoSize = true;
            label38.Location = new Point(15, 71);
            label38.Name = "label38";
            label38.Size = new Size(65, 15);
            label38.TabIndex = 1;
            label38.Text = "Resolucion";
            // 
            // label35
            // 
            label35.AutoSize = true;
            label35.Location = new Point(29, 38);
            label35.Name = "label35";
            label35.Size = new Size(51, 15);
            label35.TabIndex = 0;
            label35.Text = "Nombre";
            // 
            // panel3
            // 
            panel3.Controls.Add(cmbProfesor);
            panel3.Controls.Add(cmbCarrera);
            panel3.Controls.Add(btnReporteCarrera);
            panel3.Controls.Add(btnModificarMateria);
            panel3.Controls.Add(btnEliminarMateria);
            panel3.Controls.Add(txtIDmateria);
            panel3.Controls.Add(btnAgregarMateria);
            panel3.Controls.Add(txtAño);
            panel3.Controls.Add(txtNombreMateria);
            panel3.Controls.Add(label43);
            panel3.Controls.Add(label44);
            panel3.Controls.Add(label40);
            panel3.Controls.Add(label41);
            panel3.Controls.Add(label42);
            panel3.Location = new Point(309, 86);
            panel3.Name = "panel3";
            panel3.Size = new Size(462, 246);
            panel3.TabIndex = 63;
            // 
            // cmbProfesor
            // 
            cmbProfesor.FormattingEnabled = true;
            cmbProfesor.Location = new Point(293, 33);
            cmbProfesor.Name = "cmbProfesor";
            cmbProfesor.Size = new Size(124, 23);
            cmbProfesor.TabIndex = 71;
            cmbProfesor.DropDown += cmbProfesor_DropDown;
            // 
            // cmbCarrera
            // 
            cmbCarrera.FormattingEnabled = true;
            cmbCarrera.Location = new Point(94, 68);
            cmbCarrera.Name = "cmbCarrera";
            cmbCarrera.Size = new Size(126, 23);
            cmbCarrera.TabIndex = 70;
            cmbCarrera.DropDown += cmbCarrera_DropDown;
            // 
            // btnReporteCarrera
            // 
            btnReporteCarrera.Location = new Point(344, 198);
            btnReporteCarrera.Name = "btnReporteCarrera";
            btnReporteCarrera.Size = new Size(100, 33);
            btnReporteCarrera.TabIndex = 69;
            btnReporteCarrera.Text = "Reporte";
            btnReporteCarrera.UseVisualStyleBackColor = true;
            btnReporteCarrera.Click += btnReporteCarrera_Click;
            // 
            // btnModificarMateria
            // 
            btnModificarMateria.Location = new Point(94, 198);
            btnModificarMateria.Name = "btnModificarMateria";
            btnModificarMateria.Size = new Size(67, 33);
            btnModificarMateria.TabIndex = 69;
            btnModificarMateria.Text = "Modificar";
            btnModificarMateria.UseVisualStyleBackColor = true;
            btnModificarMateria.Click += btnModificarMateria_Click;
            // 
            // btnEliminarMateria
            // 
            btnEliminarMateria.Location = new Point(167, 198);
            btnEliminarMateria.Name = "btnEliminarMateria";
            btnEliminarMateria.Size = new Size(67, 33);
            btnEliminarMateria.TabIndex = 68;
            btnEliminarMateria.Text = "Eliminar";
            btnEliminarMateria.UseVisualStyleBackColor = true;
            btnEliminarMateria.Click += btnEliminarMateria_Click;
            // 
            // txtIDmateria
            // 
            txtIDmateria.Location = new Point(293, 68);
            txtIDmateria.Name = "txtIDmateria";
            txtIDmateria.Size = new Size(124, 23);
            txtIDmateria.TabIndex = 12;
            // 
            // btnAgregarMateria
            // 
            btnAgregarMateria.Location = new Point(21, 198);
            btnAgregarMateria.Name = "btnAgregarMateria";
            btnAgregarMateria.Size = new Size(67, 33);
            btnAgregarMateria.TabIndex = 67;
            btnAgregarMateria.Text = "Agregar";
            btnAgregarMateria.UseVisualStyleBackColor = true;
            btnAgregarMateria.Click += btnAgregarMateria_Click;
            // 
            // txtAño
            // 
            txtAño.Location = new Point(94, 106);
            txtAño.Name = "txtAño";
            txtAño.Size = new Size(124, 23);
            txtAño.TabIndex = 10;
            // 
            // txtNombreMateria
            // 
            txtNombreMateria.Location = new Point(94, 33);
            txtNombreMateria.Name = "txtNombreMateria";
            txtNombreMateria.Size = new Size(124, 23);
            txtNombreMateria.TabIndex = 8;
            // 
            // label43
            // 
            label43.AutoSize = true;
            label43.Location = new Point(226, 71);
            label43.Name = "label43";
            label43.Size = new Size(61, 15);
            label43.TabIndex = 7;
            label43.Text = "ID Materia";
            // 
            // label44
            // 
            label44.AutoSize = true;
            label44.Location = new Point(236, 38);
            label44.Name = "label44";
            label44.Size = new Size(51, 15);
            label44.TabIndex = 6;
            label44.Text = "Profesor";
            // 
            // label40
            // 
            label40.AutoSize = true;
            label40.Location = new Point(53, 109);
            label40.Name = "label40";
            label40.Size = new Size(29, 15);
            label40.TabIndex = 5;
            label40.Text = "Año";
            // 
            // label41
            // 
            label41.AutoSize = true;
            label41.Location = new Point(37, 71);
            label41.Name = "label41";
            label41.Size = new Size(45, 15);
            label41.TabIndex = 4;
            label41.Text = "Carrera";
            // 
            // label42
            // 
            label42.AutoSize = true;
            label42.Location = new Point(37, 38);
            label42.Name = "label42";
            label42.Size = new Size(51, 15);
            label42.TabIndex = 3;
            label42.Text = "Nombre";
            // 
            // label37
            // 
            label37.AutoSize = true;
            label37.Font = new Font("Segoe UI", 21.75F);
            label37.Location = new Point(788, 24);
            label37.Name = "label37";
            label37.Size = new Size(250, 40);
            label37.TabIndex = 62;
            label37.Text = "Visualizar Carreras";
            // 
            // label36
            // 
            label36.AutoSize = true;
            label36.Font = new Font("Segoe UI", 21.75F);
            label36.Location = new Point(423, 24);
            label36.Name = "label36";
            label36.Size = new Size(232, 40);
            label36.TabIndex = 61;
            label36.Text = "Gestion Materias";
            // 
            // label34
            // 
            label34.AutoSize = true;
            label34.Font = new Font("Segoe UI", 21.75F);
            label34.Location = new Point(26, 24);
            label34.Name = "label34";
            label34.Size = new Size(240, 40);
            label34.TabIndex = 60;
            label34.Text = "Gestionar Carrera";
            // 
            // tabGestionPersonal
            // 
            tabGestionPersonal.Controls.Add(btnReportePersonalAdmin);
            tabGestionPersonal.Controls.Add(dtgPersonalAdministrativo);
            tabGestionPersonal.Controls.Add(btnBuscarAdmin);
            tabGestionPersonal.Controls.Add(btnModificarPersonal);
            tabGestionPersonal.Controls.Add(btnEliminarPersonal);
            tabGestionPersonal.Controls.Add(btnAgregarPersonal);
            tabGestionPersonal.Controls.Add(txtIDpersonal);
            tabGestionPersonal.Controls.Add(label56);
            tabGestionPersonal.Controls.Add(txtDomicilioNumeroPersnonal);
            tabGestionPersonal.Controls.Add(label46);
            tabGestionPersonal.Controls.Add(txtContraseñaPersonal);
            tabGestionPersonal.Controls.Add(txtUsuarioPersonal);
            tabGestionPersonal.Controls.Add(txtEmailPersonal);
            tabGestionPersonal.Controls.Add(txtTelefonoPersonal);
            tabGestionPersonal.Controls.Add(txtDomicilioCallePersonal);
            tabGestionPersonal.Controls.Add(txtDNIpersnal);
            tabGestionPersonal.Controls.Add(txtApellidoPersonal);
            tabGestionPersonal.Controls.Add(txtNombrePersonal);
            tabGestionPersonal.Controls.Add(label47);
            tabGestionPersonal.Controls.Add(label48);
            tabGestionPersonal.Controls.Add(label49);
            tabGestionPersonal.Controls.Add(label50);
            tabGestionPersonal.Controls.Add(label51);
            tabGestionPersonal.Controls.Add(label52);
            tabGestionPersonal.Controls.Add(label53);
            tabGestionPersonal.Controls.Add(label54);
            tabGestionPersonal.Controls.Add(label55);
            tabGestionPersonal.Location = new Point(4, 24);
            tabGestionPersonal.Name = "tabGestionPersonal";
            tabGestionPersonal.Padding = new Padding(3);
            tabGestionPersonal.Size = new Size(1062, 470);
            tabGestionPersonal.TabIndex = 4;
            tabGestionPersonal.Text = "Gestion Personal Administrativo";
            tabGestionPersonal.UseVisualStyleBackColor = true;
            // 
            // btnReportePersonalAdmin
            // 
            btnReportePersonalAdmin.Location = new Point(764, 303);
            btnReportePersonalAdmin.Name = "btnReportePersonalAdmin";
            btnReportePersonalAdmin.Size = new Size(121, 33);
            btnReportePersonalAdmin.TabIndex = 90;
            btnReportePersonalAdmin.Text = "Reporte";
            btnReportePersonalAdmin.UseVisualStyleBackColor = true;
            btnReportePersonalAdmin.Click += btnReportePersonalAdmin_Click;
            // 
            // dtgPersonalAdministrativo
            // 
            dtgPersonalAdministrativo.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgPersonalAdministrativo.Location = new Point(9, 342);
            dtgPersonalAdministrativo.Name = "dtgPersonalAdministrativo";
            dtgPersonalAdministrativo.Size = new Size(1045, 150);
            dtgPersonalAdministrativo.TabIndex = 89;
            dtgPersonalAdministrativo.CellDoubleClick += dtgPersonalAdministrativo_CellDoubleClick;
            // 
            // btnBuscarAdmin
            // 
            btnBuscarAdmin.Location = new Point(911, 290);
            btnBuscarAdmin.Name = "btnBuscarAdmin";
            btnBuscarAdmin.Size = new Size(143, 46);
            btnBuscarAdmin.TabIndex = 88;
            btnBuscarAdmin.Text = "Buscar";
            btnBuscarAdmin.UseVisualStyleBackColor = true;
            btnBuscarAdmin.Click += btnBuscarAdmin_Click;
            // 
            // btnModificarPersonal
            // 
            btnModificarPersonal.Location = new Point(103, 290);
            btnModificarPersonal.Name = "btnModificarPersonal";
            btnModificarPersonal.Size = new Size(86, 46);
            btnModificarPersonal.TabIndex = 87;
            btnModificarPersonal.Text = "Modificar";
            btnModificarPersonal.UseVisualStyleBackColor = true;
            btnModificarPersonal.Click += btnModificarPersonal_Click;
            // 
            // btnEliminarPersonal
            // 
            btnEliminarPersonal.Location = new Point(195, 290);
            btnEliminarPersonal.Name = "btnEliminarPersonal";
            btnEliminarPersonal.Size = new Size(86, 46);
            btnEliminarPersonal.TabIndex = 86;
            btnEliminarPersonal.Text = "Eliminar";
            btnEliminarPersonal.UseVisualStyleBackColor = true;
            btnEliminarPersonal.Click += btnEliminarPersonal_Click;
            // 
            // btnAgregarPersonal
            // 
            btnAgregarPersonal.Location = new Point(11, 290);
            btnAgregarPersonal.Name = "btnAgregarPersonal";
            btnAgregarPersonal.Size = new Size(86, 46);
            btnAgregarPersonal.TabIndex = 85;
            btnAgregarPersonal.Text = "Agregar";
            btnAgregarPersonal.UseVisualStyleBackColor = true;
            btnAgregarPersonal.Click += btnAgregarPersonal_Click;
            // 
            // txtIDpersonal
            // 
            txtIDpersonal.Location = new Point(863, 124);
            txtIDpersonal.Name = "txtIDpersonal";
            txtIDpersonal.Size = new Size(124, 23);
            txtIDpersonal.TabIndex = 84;
            // 
            // label56
            // 
            label56.AutoSize = true;
            label56.Font = new Font("Segoe UI", 21.75F);
            label56.Location = new Point(320, 36);
            label56.Name = "label56";
            label56.Size = new Size(419, 40);
            label56.TabIndex = 83;
            label56.Text = "Gestion Personal Administrador";
            // 
            // txtDomicilioNumeroPersnonal
            // 
            txtDomicilioNumeroPersnonal.Location = new Point(356, 124);
            txtDomicilioNumeroPersnonal.Name = "txtDomicilioNumeroPersnonal";
            txtDomicilioNumeroPersnonal.Size = new Size(124, 23);
            txtDomicilioNumeroPersnonal.TabIndex = 81;
            // 
            // label46
            // 
            label46.AutoSize = true;
            label46.Location = new Point(289, 176);
            label46.Name = "label46";
            label46.Size = new Size(58, 15);
            label46.TabIndex = 80;
            label46.Text = "Domicilio";
            // 
            // txtContraseñaPersonal
            // 
            txtContraseñaPersonal.Location = new Point(636, 169);
            txtContraseñaPersonal.Name = "txtContraseñaPersonal";
            txtContraseñaPersonal.Size = new Size(124, 23);
            txtContraseñaPersonal.TabIndex = 79;
            // 
            // txtUsuarioPersonal
            // 
            txtUsuarioPersonal.Location = new Point(636, 124);
            txtUsuarioPersonal.Name = "txtUsuarioPersonal";
            txtUsuarioPersonal.Size = new Size(124, 23);
            txtUsuarioPersonal.TabIndex = 78;
            // 
            // txtEmailPersonal
            // 
            txtEmailPersonal.Location = new Point(636, 220);
            txtEmailPersonal.Name = "txtEmailPersonal";
            txtEmailPersonal.Size = new Size(124, 23);
            txtEmailPersonal.TabIndex = 77;
            // 
            // txtTelefonoPersonal
            // 
            txtTelefonoPersonal.Location = new Point(356, 220);
            txtTelefonoPersonal.Name = "txtTelefonoPersonal";
            txtTelefonoPersonal.Size = new Size(124, 23);
            txtTelefonoPersonal.TabIndex = 76;
            // 
            // txtDomicilioCallePersonal
            // 
            txtDomicilioCallePersonal.Location = new Point(356, 169);
            txtDomicilioCallePersonal.Name = "txtDomicilioCallePersonal";
            txtDomicilioCallePersonal.Size = new Size(124, 23);
            txtDomicilioCallePersonal.TabIndex = 75;
            // 
            // txtDNIpersnal
            // 
            txtDNIpersnal.Location = new Point(103, 217);
            txtDNIpersnal.Name = "txtDNIpersnal";
            txtDNIpersnal.Size = new Size(124, 23);
            txtDNIpersnal.TabIndex = 74;
            // 
            // txtApellidoPersonal
            // 
            txtApellidoPersonal.Location = new Point(103, 169);
            txtApellidoPersonal.Name = "txtApellidoPersonal";
            txtApellidoPersonal.Size = new Size(124, 23);
            txtApellidoPersonal.TabIndex = 73;
            // 
            // txtNombrePersonal
            // 
            txtNombrePersonal.Location = new Point(103, 124);
            txtNombrePersonal.Name = "txtNombrePersonal";
            txtNombrePersonal.Size = new Size(124, 23);
            txtNombrePersonal.TabIndex = 72;
            // 
            // label47
            // 
            label47.AutoSize = true;
            label47.Location = new Point(821, 127);
            label47.Name = "label47";
            label47.Size = new Size(18, 15);
            label47.TabIndex = 71;
            label47.Text = "ID";
            // 
            // label48
            // 
            label48.AutoSize = true;
            label48.Location = new Point(555, 176);
            label48.Name = "label48";
            label48.Size = new Size(67, 15);
            label48.TabIndex = 70;
            label48.Text = "Contraseña";
            // 
            // label49
            // 
            label49.AutoSize = true;
            label49.Location = new Point(575, 127);
            label49.Name = "label49";
            label49.Size = new Size(47, 15);
            label49.TabIndex = 69;
            label49.Text = "Usuario";
            // 
            // label50
            // 
            label50.AutoSize = true;
            label50.Location = new Point(575, 223);
            label50.Name = "label50";
            label50.Size = new Size(36, 15);
            label50.TabIndex = 68;
            label50.Text = "Email";
            // 
            // label51
            // 
            label51.AutoSize = true;
            label51.Location = new Point(295, 223);
            label51.Name = "label51";
            label51.Size = new Size(52, 15);
            label51.TabIndex = 67;
            label51.Text = "Telefono";
            // 
            // label52
            // 
            label52.AutoSize = true;
            label52.Location = new Point(259, 132);
            label52.Name = "label52";
            label52.Size = new Size(91, 15);
            label52.TabIndex = 66;
            label52.Text = "Domicilio altura";
            // 
            // label53
            // 
            label53.AutoSize = true;
            label53.Location = new Point(46, 220);
            label53.Name = "label53";
            label53.Size = new Size(25, 15);
            label53.TabIndex = 65;
            label53.Text = "Dni";
            // 
            // label54
            // 
            label54.AutoSize = true;
            label54.Location = new Point(46, 172);
            label54.Name = "label54";
            label54.Size = new Size(51, 15);
            label54.TabIndex = 64;
            label54.Text = "Apellido";
            // 
            // label55
            // 
            label55.AutoSize = true;
            label55.Location = new Point(46, 127);
            label55.Name = "label55";
            label55.Size = new Size(51, 15);
            label55.TabIndex = 63;
            label55.Text = "Nombre";
            // 
            // error1
            // 
            error1.ContainerControl = this;
            // 
            // btnMinimizar
            // 
            btnMinimizar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnMinimizar.BackColor = Color.LightGray;
            btnMinimizar.FlatAppearance.BorderColor = Color.White;
            btnMinimizar.FlatAppearance.MouseOverBackColor = Color.FromArgb(64, 64, 64);
            btnMinimizar.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnMinimizar.Location = new Point(956, 12);
            btnMinimizar.Name = "btnMinimizar";
            btnMinimizar.Size = new Size(50, 24);
            btnMinimizar.TabIndex = 12;
            btnMinimizar.Text = "-";
            btnMinimizar.UseVisualStyleBackColor = false;
            btnMinimizar.Click += btnMinimizar_Click;
            // 
            // button1
            // 
            button1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            button1.BackColor = Color.LightGray;
            button1.FlatAppearance.BorderColor = Color.White;
            button1.FlatAppearance.MouseOverBackColor = Color.FromArgb(64, 64, 64);
            button1.Location = new Point(1015, 12);
            button1.Name = "button1";
            button1.Size = new Size(43, 24);
            button1.TabIndex = 11;
            button1.Text = "X";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // Administrador
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(49, 66, 82);
            ClientSize = new Size(1070, 526);
            Controls.Add(btnMinimizar);
            Controls.Add(button1);
            Controls.Add(tabControl1);
            Name = "Administrador";
            Text = "Administrador";
            tabControl1.ResumeLayout(false);
            tpGestionProfesores.ResumeLayout(false);
            tpGestionProfesores.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dtgProfesores).EndInit();
            tpGestionExamenes.ResumeLayout(false);
            tpGestionExamenes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dtgNotasAdmin).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            tpGestionAlumnos.ResumeLayout(false);
            tpGestionAlumnos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dtgAlumnos).EndInit();
            tabPage4.ResumeLayout(false);
            tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dtgCarrera).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            tabGestionPersonal.ResumeLayout(false);
            tabGestionPersonal.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dtgPersonalAdministrativo).EndInit();
            ((System.ComponentModel.ISupportInitialize)error1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tpGestionProfesores;
        private TabPage tpGestionExamenes;
        private TabPage tpGestionAlumnos;
        private TabPage tabPage4;
        private TabPage tabGestionPersonal;
        private TextBox txtIDProfesor;
        private TextBox txtContraseñaProfesor;
        private TextBox txtUsuarioProfesor;
        private TextBox txtEmailProfesor;
        private TextBox txtTelefonoProfesor;
        private TextBox txtDomicilioAlturaProfesor;
        private TextBox txtDomicilioProfesor;
        private TextBox txtDNIprofesor;
        private TextBox txtApellidoProfesor;
        private TextBox txtNombreProfesor;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private DataGridView dtgProfesores;
        private Button btnBuscar;
        private Button btnReporteProfesores;
        private Button btnModificarProfesor;
        private Button btnEliminarProfesor;
        private Button btnAgregarProfesor;
        private Panel panel2;
        private Panel panel1;
        private Label label12;
        private DataGridView dtgNotasAdmin;
        private TextBox txtMatriculaNota;
        private TextBox txtDniNotaAdmin;
        private TextBox txtApellidoNota;
        private Label label22;
        private Label label19;
        private TextBox txtNombreNota;
        private Label label20;
        private Label label21;
        private Button btnModificarNota;
        private TextBox txtMatriculaExamenes;
        private Button btnAgregarNota;
        private TextBox txtFolio;
        private TextBox txtLibro;
        private TextBox txtNota;
        private ComboBox cmbInstanciaExamenes;
        private ComboBox cmbMateriaExamenes;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label15;
        private Label label14;
        private Label label13;
        private Button btnReportesExamenes;
        private Button btnBuscarNota;
        private TextBox textBox15;
        private Label label33;
        private Label label32;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox5;
        private TextBox textBox6;
        private TextBox txtNombreAlumno;
        private Label label23;
        private Label label24;
        private Label label25;
        private Label label26;
        private Label label27;
        private Label label28;
        private Label label29;
        private Label label30;
        private Label label31;
        private ComboBox cmbFiltroAlumnos;
        private Button btnReporteAlumno;
        private Button btnBuscarAlumno;
        private Button btnModificarAlumno;
        private Button btnEliminarAlumno;
        private Button btnAgregarAlumno;
        private DataGridView dtgAlumnos;
        private Panel panel5;
        private Panel panel4;
        private Panel panel3;
        private Label label37;
        private Label label36;
        private Label label34;
        private Button btnBuscarCarreras;
        private Label label45;
        private ComboBox cmbVisualizarCarreras;
        private TextBox txtDuracion;
        private Button btnEliminarCarrera;
        private TextBox txtResolucion;
        private Button btnAgregarCarrera;
        private TextBox txtCarreraNombre;
        private Label label39;
        private Label label38;
        private Label label35;
        private Button btnReporteCarrera;
        private Button btnModificarMateria;
        private Button btnEliminarMateria;
        private TextBox txtIDmateria;
        private Button btnAgregarMateria;
        private TextBox txtAño;
        private TextBox txtNombreMateria;
        private Label label43;
        private Label label44;
        private Label label40;
        private Label label41;
        private Label label42;
        private ComboBox cmbCarrera;
        private ComboBox cmbProfesor;
        private DataGridView dtgCarrera;
        private DataGridView dtgPersonalAdministrativo;
        private Button btnBuscarAdmin;
        private Button btnModificarPersonal;
        private Button btnEliminarPersonal;
        private Button btnAgregarPersonal;
        private TextBox txtIDpersonal;
        private Label label56;
        private TextBox txtDomicilioNumeroPersnonal;
        private Label label46;
        private TextBox txtContraseñaPersonal;
        private TextBox txtUsuarioPersonal;
        private TextBox txtEmailPersonal;
        private TextBox txtTelefonoPersonal;
        private TextBox txtDomicilioCallePersonal;
        private TextBox txtDNIpersnal;
        private TextBox txtApellidoPersonal;
        private TextBox txtNombrePersonal;
        private Label label47;
        private Label label48;
        private Label label49;
        private Label label50;
        private Label label51;
        private Label label52;
        private Label label53;
        private Label label54;
        private Label label55;
        private Button btnReportePersonalAdmin;
        private TextBox txtEmailAlumno;
        private TextBox txtContraseñaAlumno;
        private TextBox txtUsuarioAlumno;
        private TextBox txtTelefonAlumno;
        private TextBox txtDomiciloAltAlumno;
        private TextBox txtDomiciloAlumno;
        private TextBox txtDNIalumno;
        private TextBox txtApellidoAlumno;
        private ErrorProvider error1;
        private Label label57;
        private Button btnMinimizar;
        private Button button1;
        private TextBox txtMatriculaAlumnos;
        private Label label58;
    }
}