﻿namespace HILET
{
    partial class frmPersonalAdministrativo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pnlMenu = new Panel();
            panel6 = new Panel();
            btnCerrarSesion = new Button();
            panel5 = new Panel();
            btnMaterias = new Button();
            panel4 = new Panel();
            btnEstadisticas = new Button();
            panel3 = new Panel();
            panel2 = new Panel();
            panel1 = new Panel();
            btnExamenes = new Button();
            btnCarreras = new Button();
            btnAlumnos = new Button();
            pictureBox1 = new PictureBox();
            pnlContenido = new Panel();
            pictureBox2 = new PictureBox();
            lblInformacion = new Label();
            lblBienvenida = new Label();
            lblBienvenida2 = new Label();
            btnSalir = new Button();
            pnlSuperior = new Panel();
            btnMinimizar = new Button();
            menustrip1 = new MenuStrip();
            accesoDirectoToolStripMenuItem = new ToolStripMenuItem();
            alumnosToolStripMenuItem = new ToolStripMenuItem();
            carrerasToolStripMenuItem = new ToolStripMenuItem();
            materiasToolStripMenuItem = new ToolStripMenuItem();
            examenesToolStripMenuItem = new ToolStripMenuItem();
            estadisticasToolStripMenuItem = new ToolStripMenuItem();
            ayudaToolStripMenuItem = new ToolStripMenuItem();
            ajustesToolStripMenuItem = new ToolStripMenuItem();
            cambiarUsuarioContraseñaToolStripMenuItem = new ToolStripMenuItem();
            pnlMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            pnlContenido.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            pnlSuperior.SuspendLayout();
            menustrip1.SuspendLayout();
            SuspendLayout();
            // 
            // pnlMenu
            // 
            pnlMenu.BackColor = Color.FromArgb(33, 63, 97);
            pnlMenu.Controls.Add(panel6);
            pnlMenu.Controls.Add(btnCerrarSesion);
            pnlMenu.Controls.Add(panel5);
            pnlMenu.Controls.Add(btnMaterias);
            pnlMenu.Controls.Add(panel4);
            pnlMenu.Controls.Add(btnEstadisticas);
            pnlMenu.Controls.Add(panel3);
            pnlMenu.Controls.Add(panel2);
            pnlMenu.Controls.Add(panel1);
            pnlMenu.Controls.Add(btnExamenes);
            pnlMenu.Controls.Add(btnCarreras);
            pnlMenu.Controls.Add(btnAlumnos);
            pnlMenu.Controls.Add(pictureBox1);
            pnlMenu.Dock = DockStyle.Left;
            pnlMenu.Location = new Point(0, 35);
            pnlMenu.Name = "pnlMenu";
            pnlMenu.Size = new Size(220, 491);
            pnlMenu.TabIndex = 1;
            // 
            // panel6
            // 
            panel6.BackColor = Color.FromArgb(46, 89, 134);
            panel6.Location = new Point(1, 438);
            panel6.Name = "panel6";
            panel6.Size = new Size(10, 32);
            panel6.TabIndex = 6;
            // 
            // btnCerrarSesion
            // 
            btnCerrarSesion.BackColor = Color.FromArgb(33, 63, 97);
            btnCerrarSesion.FlatAppearance.BorderSize = 0;
            btnCerrarSesion.FlatAppearance.MouseOverBackColor = Color.FromArgb(46, 89, 134);
            btnCerrarSesion.FlatStyle = FlatStyle.Flat;
            btnCerrarSesion.Font = new Font("Century Gothic", 11.25F);
            btnCerrarSesion.ForeColor = Color.White;
            btnCerrarSesion.Image = Properties.Resources.CerrarSesion;
            btnCerrarSesion.ImageAlign = ContentAlignment.MiddleLeft;
            btnCerrarSesion.Location = new Point(9, 438);
            btnCerrarSesion.Name = "btnCerrarSesion";
            btnCerrarSesion.Size = new Size(208, 32);
            btnCerrarSesion.TabIndex = 10;
            btnCerrarSesion.Text = "Cerrar sesiòn";
            btnCerrarSesion.UseVisualStyleBackColor = false;
            btnCerrarSesion.Click += btnCerrarSesion_Click;
            // 
            // panel5
            // 
            panel5.BackColor = Color.FromArgb(46, 89, 134);
            panel5.Location = new Point(1, 210);
            panel5.Name = "panel5";
            panel5.Size = new Size(10, 32);
            panel5.TabIndex = 9;
            // 
            // btnMaterias
            // 
            btnMaterias.BackColor = Color.FromArgb(33, 63, 97);
            btnMaterias.FlatAppearance.BorderSize = 0;
            btnMaterias.FlatAppearance.MouseOverBackColor = Color.FromArgb(46, 89, 134);
            btnMaterias.FlatStyle = FlatStyle.Flat;
            btnMaterias.Font = new Font("Century Gothic", 11.25F);
            btnMaterias.ForeColor = Color.White;
            btnMaterias.Image = Properties.Resources.materias;
            btnMaterias.ImageAlign = ContentAlignment.MiddleLeft;
            btnMaterias.Location = new Point(12, 210);
            btnMaterias.Name = "btnMaterias";
            btnMaterias.Size = new Size(208, 32);
            btnMaterias.TabIndex = 8;
            btnMaterias.Text = "Materias";
            btnMaterias.UseVisualStyleBackColor = false;
            btnMaterias.Click += btnMaterias_Click;
            // 
            // panel4
            // 
            panel4.BackColor = Color.FromArgb(46, 89, 134);
            panel4.Location = new Point(1, 319);
            panel4.Name = "panel4";
            panel4.Size = new Size(10, 32);
            panel4.TabIndex = 7;
            // 
            // btnEstadisticas
            // 
            btnEstadisticas.BackColor = Color.FromArgb(33, 63, 97);
            btnEstadisticas.FlatAppearance.BorderSize = 0;
            btnEstadisticas.FlatAppearance.MouseOverBackColor = Color.FromArgb(46, 89, 134);
            btnEstadisticas.FlatStyle = FlatStyle.Flat;
            btnEstadisticas.Font = new Font("Century Gothic", 11.25F);
            btnEstadisticas.ForeColor = Color.White;
            btnEstadisticas.Image = Properties.Resources.Reporte;
            btnEstadisticas.ImageAlign = ContentAlignment.MiddleLeft;
            btnEstadisticas.Location = new Point(12, 319);
            btnEstadisticas.Name = "btnEstadisticas";
            btnEstadisticas.Size = new Size(208, 32);
            btnEstadisticas.TabIndex = 6;
            btnEstadisticas.Text = "Estadisticas";
            btnEstadisticas.UseVisualStyleBackColor = false;
            btnEstadisticas.Click += btnEstadisticas_Click;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(46, 89, 134);
            panel3.Location = new Point(1, 265);
            panel3.Name = "panel3";
            panel3.Size = new Size(10, 32);
            panel3.TabIndex = 5;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(46, 89, 134);
            panel2.Location = new Point(1, 106);
            panel2.Name = "panel2";
            panel2.Size = new Size(10, 32);
            panel2.TabIndex = 5;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(46, 89, 134);
            panel1.Location = new Point(0, 160);
            panel1.Name = "panel1";
            panel1.Size = new Size(10, 32);
            panel1.TabIndex = 4;
            // 
            // btnExamenes
            // 
            btnExamenes.BackColor = Color.FromArgb(33, 63, 97);
            btnExamenes.FlatAppearance.BorderSize = 0;
            btnExamenes.FlatAppearance.MouseOverBackColor = Color.FromArgb(46, 89, 134);
            btnExamenes.FlatStyle = FlatStyle.Flat;
            btnExamenes.Font = new Font("Century Gothic", 11.25F);
            btnExamenes.ForeColor = Color.White;
            btnExamenes.Image = Properties.Resources.Examenes;
            btnExamenes.ImageAlign = ContentAlignment.MiddleLeft;
            btnExamenes.Location = new Point(12, 265);
            btnExamenes.Name = "btnExamenes";
            btnExamenes.Size = new Size(208, 32);
            btnExamenes.TabIndex = 3;
            btnExamenes.Text = "Examenes";
            btnExamenes.UseVisualStyleBackColor = false;
            btnExamenes.Click += btnExamenes_Click;
            // 
            // btnCarreras
            // 
            btnCarreras.BackColor = Color.FromArgb(33, 63, 97);
            btnCarreras.FlatAppearance.BorderSize = 0;
            btnCarreras.FlatAppearance.MouseOverBackColor = Color.FromArgb(46, 89, 134);
            btnCarreras.FlatStyle = FlatStyle.Flat;
            btnCarreras.Font = new Font("Century Gothic", 11.25F);
            btnCarreras.ForeColor = Color.White;
            btnCarreras.Image = Properties.Resources.Carreras;
            btnCarreras.ImageAlign = ContentAlignment.MiddleLeft;
            btnCarreras.Location = new Point(12, 160);
            btnCarreras.Name = "btnCarreras";
            btnCarreras.Size = new Size(208, 32);
            btnCarreras.TabIndex = 2;
            btnCarreras.Text = "Carreras";
            btnCarreras.UseVisualStyleBackColor = false;
            btnCarreras.Click += btnCarreras_Click;
            // 
            // btnAlumnos
            // 
            btnAlumnos.BackColor = Color.FromArgb(33, 63, 97);
            btnAlumnos.FlatAppearance.BorderSize = 0;
            btnAlumnos.FlatAppearance.MouseOverBackColor = Color.FromArgb(46, 89, 134);
            btnAlumnos.FlatStyle = FlatStyle.Flat;
            btnAlumnos.Font = new Font("Century Gothic", 11.25F);
            btnAlumnos.ForeColor = Color.White;
            btnAlumnos.Image = Properties.Resources.student_work_office_desk_work_space_computer_working_support_icon_191191;
            btnAlumnos.ImageAlign = ContentAlignment.MiddleLeft;
            btnAlumnos.Location = new Point(9, 109);
            btnAlumnos.Name = "btnAlumnos";
            btnAlumnos.Size = new Size(208, 32);
            btnAlumnos.TabIndex = 1;
            btnAlumnos.Text = "Alumnos";
            btnAlumnos.UseVisualStyleBackColor = false;
            btnAlumnos.Click += btnAlumnos_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Hilet;
            pictureBox1.Location = new Point(3, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(217, 103);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // pnlContenido
            // 
            pnlContenido.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            pnlContenido.BackColor = Color.FromArgb(49, 66, 82);
            pnlContenido.Controls.Add(pictureBox2);
            pnlContenido.Controls.Add(lblInformacion);
            pnlContenido.Controls.Add(lblBienvenida);
            pnlContenido.Controls.Add(lblBienvenida2);
            pnlContenido.Dock = DockStyle.Fill;
            pnlContenido.Location = new Point(220, 35);
            pnlContenido.Name = "pnlContenido";
            pnlContenido.Size = new Size(850, 491);
            pnlContenido.TabIndex = 2;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.FotoBienvenida;
            pictureBox2.Location = new Point(22, 225);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(804, 206);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 3;
            pictureBox2.TabStop = false;
            // 
            // lblInformacion
            // 
            lblInformacion.AutoSize = true;
            lblInformacion.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblInformacion.ForeColor = Color.Transparent;
            lblInformacion.Location = new Point(6, 465);
            lblInformacion.Name = "lblInformacion";
            lblInformacion.Size = new Size(782, 17);
            lblInformacion.TabIndex = 2;
            lblInformacion.Text = "INSTITUTO HILET | 25 de Mayo y Mitre | Tel/Fax: (0223) 493-2525 | Email: informes@hilet.com | Mar del Plata, Buenos Aires, Argentina";
            // 
            // lblBienvenida
            // 
            lblBienvenida.AutoSize = true;
            lblBienvenida.Font = new Font("Sitka Small", 24F, FontStyle.Italic | FontStyle.Underline, GraphicsUnit.Point, 0);
            lblBienvenida.ForeColor = Color.White;
            lblBienvenida.Location = new Point(349, 143);
            lblBienvenida.Name = "lblBienvenida";
            lblBienvenida.Size = new Size(140, 48);
            lblBienvenida.TabIndex = 1;
            lblBienvenida.Text = "usuario";
            // 
            // lblBienvenida2
            // 
            lblBienvenida2.AutoSize = true;
            lblBienvenida2.Font = new Font("Sitka Small", 48F, FontStyle.Italic | FontStyle.Underline, GraphicsUnit.Point, 0);
            lblBienvenida2.ForeColor = Color.White;
            lblBienvenida2.Location = new Point(162, 30);
            lblBienvenida2.Name = "lblBienvenida2";
            lblBienvenida2.Size = new Size(541, 94);
            lblBienvenida2.TabIndex = 0;
            lblBienvenida2.Text = "BIENVENIDO/A";
            // 
            // btnSalir
            // 
            btnSalir.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnSalir.BackColor = Color.LightGray;
            btnSalir.FlatAppearance.BorderColor = Color.White;
            btnSalir.FlatAppearance.MouseOverBackColor = Color.FromArgb(64, 64, 64);
            btnSalir.Location = new Point(1017, 8);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(43, 24);
            btnSalir.TabIndex = 5;
            btnSalir.Text = "X";
            btnSalir.UseVisualStyleBackColor = false;
            btnSalir.Click += btnSalir_Click;
            // 
            // pnlSuperior
            // 
            pnlSuperior.BackColor = Color.FromArgb(46, 89, 134);
            pnlSuperior.Controls.Add(btnMinimizar);
            pnlSuperior.Controls.Add(btnSalir);
            pnlSuperior.Controls.Add(menustrip1);
            pnlSuperior.Dock = DockStyle.Top;
            pnlSuperior.ForeColor = Color.Red;
            pnlSuperior.Location = new Point(0, 0);
            pnlSuperior.Name = "pnlSuperior";
            pnlSuperior.Size = new Size(1070, 35);
            pnlSuperior.TabIndex = 0;
            // 
            // btnMinimizar
            // 
            btnMinimizar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnMinimizar.BackColor = Color.LightGray;
            btnMinimizar.FlatAppearance.BorderColor = Color.White;
            btnMinimizar.FlatAppearance.MouseOverBackColor = Color.FromArgb(64, 64, 64);
            btnMinimizar.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnMinimizar.Location = new Point(958, 8);
            btnMinimizar.Name = "btnMinimizar";
            btnMinimizar.Size = new Size(50, 24);
            btnMinimizar.TabIndex = 7;
            btnMinimizar.Text = "-";
            btnMinimizar.UseVisualStyleBackColor = false;
            btnMinimizar.Click += btnMinimizar_Click;
            // 
            // menustrip1
            // 
            menustrip1.BackColor = Color.FromArgb(46, 89, 134);
            menustrip1.Dock = DockStyle.None;
            menustrip1.Items.AddRange(new ToolStripItem[] { accesoDirectoToolStripMenuItem, ayudaToolStripMenuItem, ajustesToolStripMenuItem });
            menustrip1.Location = new Point(1, 11);
            menustrip1.Name = "menustrip1";
            menustrip1.Size = new Size(216, 24);
            menustrip1.TabIndex = 6;
            menustrip1.Text = "menuStrip1";
            // 
            // accesoDirectoToolStripMenuItem
            // 
            accesoDirectoToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { alumnosToolStripMenuItem, carrerasToolStripMenuItem, materiasToolStripMenuItem, examenesToolStripMenuItem, estadisticasToolStripMenuItem });
            accesoDirectoToolStripMenuItem.ForeColor = Color.White;
            accesoDirectoToolStripMenuItem.Name = "accesoDirectoToolStripMenuItem";
            accesoDirectoToolStripMenuItem.Size = new Size(98, 20);
            accesoDirectoToolStripMenuItem.Text = "Acceso Directo";
            // 
            // alumnosToolStripMenuItem
            // 
            alumnosToolStripMenuItem.Name = "alumnosToolStripMenuItem";
            alumnosToolStripMenuItem.Size = new Size(134, 22);
            alumnosToolStripMenuItem.Text = "Alumnos";
            alumnosToolStripMenuItem.Click += alumnosToolStripMenuItem_Click;
            // 
            // carrerasToolStripMenuItem
            // 
            carrerasToolStripMenuItem.Name = "carrerasToolStripMenuItem";
            carrerasToolStripMenuItem.Size = new Size(134, 22);
            carrerasToolStripMenuItem.Text = "Carreras";
            carrerasToolStripMenuItem.Click += carrerasToolStripMenuItem_Click;
            // 
            // materiasToolStripMenuItem
            // 
            materiasToolStripMenuItem.Name = "materiasToolStripMenuItem";
            materiasToolStripMenuItem.Size = new Size(134, 22);
            materiasToolStripMenuItem.Text = "Materias";
            materiasToolStripMenuItem.Click += materiasToolStripMenuItem_Click;
            // 
            // examenesToolStripMenuItem
            // 
            examenesToolStripMenuItem.Name = "examenesToolStripMenuItem";
            examenesToolStripMenuItem.Size = new Size(134, 22);
            examenesToolStripMenuItem.Text = "Examenes";
            examenesToolStripMenuItem.Click += examenesToolStripMenuItem_Click;
            // 
            // estadisticasToolStripMenuItem
            // 
            estadisticasToolStripMenuItem.Name = "estadisticasToolStripMenuItem";
            estadisticasToolStripMenuItem.Size = new Size(134, 22);
            estadisticasToolStripMenuItem.Text = "Estadisticas";
            estadisticasToolStripMenuItem.Click += estadisticasToolStripMenuItem_Click;
            // 
            // ayudaToolStripMenuItem
            // 
            ayudaToolStripMenuItem.ForeColor = Color.White;
            ayudaToolStripMenuItem.Name = "ayudaToolStripMenuItem";
            ayudaToolStripMenuItem.Size = new Size(53, 20);
            ayudaToolStripMenuItem.Text = "Ayuda";
            ayudaToolStripMenuItem.Click += ayudaToolStripMenuItem_Click;
            // 
            // ajustesToolStripMenuItem
            // 
            ajustesToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { cambiarUsuarioContraseñaToolStripMenuItem });
            ajustesToolStripMenuItem.ForeColor = Color.White;
            ajustesToolStripMenuItem.Name = "ajustesToolStripMenuItem";
            ajustesToolStripMenuItem.Size = new Size(57, 20);
            ajustesToolStripMenuItem.Text = "Ajustes";
            // 
            // cambiarUsuarioContraseñaToolStripMenuItem
            // 
            cambiarUsuarioContraseñaToolStripMenuItem.Name = "cambiarUsuarioContraseñaToolStripMenuItem";
            cambiarUsuarioContraseñaToolStripMenuItem.Size = new Size(129, 22);
            cambiarUsuarioContraseñaToolStripMenuItem.Text = "Privacidad";
            cambiarUsuarioContraseñaToolStripMenuItem.Click += cambiarUsuarioContraseñaToolStripMenuItem_Click;
            // 
            // frmPersonalAdministrativo
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1070, 526);
            ControlBox = false;
            Controls.Add(pnlContenido);
            Controls.Add(pnlMenu);
            Controls.Add(pnlSuperior);
            MainMenuStrip = menustrip1;
            Name = "frmPersonalAdministrativo";
            Text = "Personal Administrativo";
            pnlMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            pnlContenido.ResumeLayout(false);
            pnlContenido.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            pnlSuperior.ResumeLayout(false);
            pnlSuperior.PerformLayout();
            menustrip1.ResumeLayout(false);
            menustrip1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Panel pnlMenu;
        private PictureBox pictureBox1;
        private Panel panel3;
        private Panel panel2;
        private Panel panel1;
        private Panel panel4;
        private Button button5;
        private Button button4;
        private Button btnEstadisticas;
        private Button btnExamenes;
        private Button btnCarreras;
        private Button btnAlumnos;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private Panel pnlContenido;
        private Button btnSalir;
        private Panel pnlSuperior;
        private Panel panel5;
        private Button btnMaterias;
        private Label lblBienvenida2;
        private Label lblBienvenida;
        private Label lblInformacion;
        private PictureBox pictureBox2;
        private Panel panel6;
        private Button btnCerrarSesion;
        private MenuStrip menustrip1;
        private ToolStripMenuItem accesoDirectoToolStripMenuItem;
        private ToolStripMenuItem alumnosToolStripMenuItem;
        private ToolStripMenuItem carrerasToolStripMenuItem;
        private ToolStripMenuItem materiasToolStripMenuItem;
        private ToolStripMenuItem examenesToolStripMenuItem;
        private ToolStripMenuItem estadisticasToolStripMenuItem;
        private ToolStripMenuItem ayudaToolStripMenuItem;
        private ToolStripMenuItem ajustesToolStripMenuItem;
        private ToolStripMenuItem cambiarUsuarioContraseñaToolStripMenuItem;
        private Button btnMinimizar;
    }
}